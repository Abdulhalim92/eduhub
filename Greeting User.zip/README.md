
  # Greeting User

  This is a code bundle for Greeting User. The original project is available at https://www.figma.com/design/w90HnkxB3opNwYzTnCfTxE/Greeting-User.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  