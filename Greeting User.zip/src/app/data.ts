// ── palette ──────────────────────────────────────────────────────────────────
export const C = {
  bg:"#07181A", s1:"#0D2527", s2:"#112C2F", s3:"#163438",
  border:"rgba(255,255,255,0.08)",
  teal:"#1BC8C4", tealD:"#0E8E8B",
  gold:"#F5C842", goldD:"#C9A030",
  red:"#E05040", text:"#FFFFFF",
  sub:"#8CB8B6", dim:"#3D6E6C", ok:"#3EC98A", muted:"#5A8A88",
};
export const FH = "'Montserrat', sans-serif";
export const FB = "'Inter', 'Montserrat', sans-serif";

// ── photos ────────────────────────────────────────────────────────────────────
const up = (id:string, w=800, h=500) =>
  `https://images.unsplash.com/${id}?w=${w}&h=${h}&fit=crop&auto=format`;

export const PHOTOS = {
  school1:       up("photo-1614595737683-1740e41bfaac"),
  school2:       up("photo-1621192754911-ffe0d95929dd"),
  school3:       up("photo-1614595737766-4d7e1fd1406f"),
  classroom:     up("photo-1509062522246-3755977927d7"),
  classroom2:    up("photo-1577896851231-70ef18881754"),
  student:       up("photo-1588072432836-e10032774350"),
  library:       up("photo-1762475833699-53a01f26565a"),
  library2:      up("photo-1680178776508-41a276595b0f"),
  kindergarten:  up("photo-1747110604852-8f3edc2451ea"),
  playground:    up("photo-1633425944465-ac84746e26f0"),
  gym:           up("photo-1768554630751-6448593749eb"),
  university:    up("photo-1577985043696-8bd54d9f093f"),
  // portraits
  pw1: up("photo-1580894732444-8ecded7900cd", 400, 400),
  pw2: up("photo-1590650213165-c1fef80648c4", 400, 400),
  pw3: up("photo-1573497019940-1c28c88b4f3e", 400, 400),
  pw4: up("photo-1585240975858-7264fd020798", 400, 400),
  pm1: up("photo-1543132220-3ec99c6094dc", 400, 400),
  pm2: up("photo-1512484776495-a09d92e87c3b", 400, 400),
  pm3: up("photo-1618306842557-a2515acf2112", 400, 400),
};

// ── types ─────────────────────────────────────────────────────────────────────
export interface Achievement {
  id: string;
  title: string;
  year: number;
  category: "gold"|"silver"|"bronze"|"special";
  desc: string;
  type: "institution"|"student"|"teacher";
}

export interface Person {
  id: string;
  instId: number;
  name: string;
  roleLabel: string;
  roleType: "director"|"teacher"|"coach"|"psychologist"|"admin";
  subject?: string;
  photo: string;
  exp: string;
  bio: string;
  education: string[];
  achievements: Achievement[];
  email?: string;
  phone?: string;
  rating?: number;
  reviews?: number;
}

export interface Metric {
  label: string;
  short: string;
  icon: string;
  v: number;
  pct: number;
}

export interface Institution {
  id: number;
  name: string;
  type: string;
  tk: string;
  area: string;
  price: number;
  score: number;
  rev: number;
  transport: boolean;
  food: boolean;
  halal: boolean;
  ver: boolean;
  color: string;
  age: string;
  tag: string|null;
  coverPhoto: string;
  gallery: {url:string; label:string}[];
  founded: number;
  students: number;
  description: string;
  achievements: Achievement[];
  metrics: Metric[];
  staff: Person[];
  address: string;
  phone: string;
  email: string;
  website: string;
  foodMenu?: { day:string; meals:{name:string;cal:string;allergens:string[]}[] }[];
}

export interface NewsArticle {
  id: string;
  title: string;
  category: string;
  coverUrl: string;
  videoUrl?: string;
  content: string;
  tags: string[];
  date: string;
  status: "published"|"draft";
  views: number;
}

// ── staff pool ────────────────────────────────────────────────────────────────
export const ALL_STAFF: Person[] = [
  {
    id:"p1", instId:1, name:"Зарнигор Рашидова", roleLabel:"Директор", roleType:"director",
    photo:PHOTOS.pw1, exp:"24 года",
    bio:"Зарнигор Алиевна руководит гимназией с 2008 года. Под её руководством школа вошла в топ-10 учебных заведений Душанбе и получила статус гимназии. Автор 3 методических пособий по педагогике.",
    education:["ТНУ — педагогика и психология, 1998","Повышение квалификации, МГУ, 2015","Cert. School Management, British Council, 2019"],
    achievements:[
      {id:"a1",title:"Заслуженный учитель РТ",year:2018,category:"gold",desc:"Высшая государственная награда в сфере образования",type:"teacher"},
      {id:"a2",title:"Лучший директор года",year:2022,category:"gold",desc:"Премия МОН Республики Таджикистан",type:"institution"},
    ],
    email:"director@sitorai.tj", phone:"+992 93 700-01-01", rating:4.9, reviews:47,
  },
  {
    id:"p2", instId:1, name:"Алишер Назаров", roleLabel:"Учитель математики", roleType:"teacher", subject:"Математика",
    photo:PHOTOS.pm1, exp:"12 лет",
    bio:"Алишер Назаров — один из лучших учителей математики в Душанбе. Его ученики ежегодно занимают призовые места на республиканских олимпиадах. Методист районного отдела образования.",
    education:["ТГУ — физико-математический факультет, 2010","Стажировка в Сколтехе, 2021"],
    achievements:[
      {id:"a3",title:"1-е место, олимпиада РТ — ученик Санги Давлатов",year:2024,category:"gold",desc:"Подготовил победителя республиканской олимпиады по математике",type:"student"},
      {id:"a4",title:"Лучший учитель математики Душанбе",year:2023,category:"silver",desc:"Профессиональный конкурс учителей",type:"teacher"},
    ],
    email:"a.nazarov@sitorai.tj", rating:4.8, reviews:89,
  },
  {
    id:"p3", instId:1, name:"Мадина Юсупова", roleLabel:"Учитель английского", roleType:"teacher", subject:"Английский язык",
    photo:PHOTOS.pw2, exp:"9 лет",
    bio:"Мадина Баходуровна — сертифицированный преподаватель английского языка (CELTA). Выпускники её классов успешно сдают IELTS и поступают в зарубежные университеты.",
    education:["ТТУ — иностранные языки, 2013","CELTA, British Council Tashkent, 2017","IELTS 7.5"],
    achievements:[
      {id:"a5",title:"Грант Fulbright — языковая программа",year:2022,category:"special",desc:"Прошла годовую стажировку в США по программе обмена учителями",type:"teacher"},
    ],
    email:"m.yusupova@sitorai.tj", rating:4.9, reviews:112,
  },
  {
    id:"p4", instId:1, name:"Бахром Каримов", roleLabel:"Учитель физики", roleType:"teacher", subject:"Физика",
    photo:PHOTOS.pm2, exp:"18 лет",
    bio:"Бахром Рустамович преподаёт физику с 2006 года. Организатор кружка робототехники и научного клуба. Его ученики — победители международных олимпиад по физике.",
    education:["ТНУ — физика, 2004","PhD (незаконч.), ТНУ, 2009"],
    achievements:[
      {id:"a6",title:"Серебро, Азиатская олимпиада по физике",year:2023,category:"silver",desc:"Воспитанник занял 2-е место на международном уровне",type:"student"},
    ],
    email:"b.karimov@sitorai.tj", rating:4.7, reviews:64,
  },
  {
    id:"p5", instId:1, name:"Нилуфар Хасанова", roleLabel:"Педагог-психолог", roleType:"psychologist",
    photo:PHOTOS.pw3, exp:"7 лет",
    bio:"Нилуфар Санджаровна занимается психологическим сопровождением учеников и родителей. Специализируется на работе с детьми с особыми образовательными потребностями.",
    education:["ТНУ — психология, 2015","Тренинг инклюзивного образования, ГИЗ, 2020"],
    achievements:[
      {id:"a7",title:"Сертификат ЮНИСЕФ — инклюзивное образование",year:2021,category:"special",desc:"Прошла международную программу по инклюзии",type:"teacher"},
    ],
    email:"n.hasanova@sitorai.tj", rating:4.8, reviews:38,
  },
  {
    id:"p6", instId:1, name:"Фируз Давлатов", roleLabel:"Тренер — физкультура", roleType:"coach", subject:"Физическая культура",
    photo:PHOTOS.pm3, exp:"11 лет",
    bio:"Фируз Бекович — мастер спорта по борьбе. Тренирует школьную сборную по волейболу и баскетболу. Команда под его руководством — трёхкратный чемпион города.",
    education:["ТГИФК — физическая культура, 2011"],
    achievements:[
      {id:"a8",title:"Чемпион г. Душанбе — волейбол",year:2024,category:"gold",desc:"Школьная сборная под руководством тренера заняла 1-е место",type:"institution"},
      {id:"a9",title:"Чемпион г. Душанбе — баскетбол",year:2023,category:"gold",desc:"Третий год подряд",type:"institution"},
    ],
    email:"f.davlatov@sitorai.tj", rating:4.7, reviews:29,
  },
];

// ── institutions ──────────────────────────────────────────────────────────────
export const INSTITUTIONS: Institution[] = [
  {
    id:1, name:"Гимназия «Ситораи Дониш»", type:"Школа", tk:"cat_school",
    area:"Сино", price:800, score:4.6, rev:214,
    transport:true, food:true, halal:true, ver:true,
    color:C.teal, age:"7–17 лет", tag:"Топ выбор",
    coverPhoto: PHOTOS.school1,
    gallery:[
      {url:PHOTOS.school1, label:"Главное здание"},
      {url:PHOTOS.classroom, label:"Класс"},
      {url:PHOTOS.library, label:"Библиотека"},
      {url:PHOTOS.gym, label:"Спортзал"},
      {url:PHOTOS.classroom2, label:"Начальная школа"},
      {url:PHOTOS.student, label:"Урок"},
    ],
    founded:1997, students:840,
    description:"Гимназия «Ситораи Дониш» — одно из ведущих учебных заведений Душанбе, основанное в 1997 году. Обучение ведётся на трёх языках: таджикском, русском и английском. Гимназия известна сильным преподавательским составом и высокими результатами учеников на олимпиадах.",
    achievements:[
      {id:"ia1",title:"Лучшая школа Душанбе",year:2024,category:"gold",desc:"По итогам ежегодного рейтинга МОН РТ среди городских школ",type:"institution"},
      {id:"ia2",title:"Топ-8% школ Таджикистана",year:2024,category:"gold",desc:"Национальный рейтинг EduHub",type:"institution"},
      {id:"ia3",title:"3 золота республиканской олимпиады",year:2024,category:"gold",desc:"По математике, физике и химии",type:"student"},
      {id:"ia4",title:"Серебро, Азиатская олимпиада физики",year:2023,category:"silver",desc:"Ученик Санги Давлатов занял 2-е место",type:"student"},
      {id:"ia5",title:"Чемпион города — волейбол",year:2024,category:"gold",desc:"Мужская сборная гимназии",type:"institution"},
      {id:"ia6",title:"Грант программы Aga Khan",year:2023,category:"special",desc:"Финансирование оснащения STEM-лаборатории",type:"institution"},
    ],
    metrics:[
      {label:"Качество обучения",short:"Обучение",icon:"📚",v:4.8,pct:96},
      {label:"Условия и помещения",short:"Условия",icon:"🏫",v:4.3,pct:86},
      {label:"Безопасность",short:"Безопасность",icon:"🔒",v:4.7,pct:94},
      {label:"Питание",short:"Питание",icon:"🍽",v:4.4,pct:88},
      {label:"Развозка",short:"Развозка",icon:"🚌",v:4.2,pct:84},
      {label:"Цена/качество",short:"Цена",icon:"💰",v:4.5,pct:90},
      {label:"Участие родителей",short:"Родители",icon:"👨‍👩‍👧",v:4.6,pct:92},
      {label:"Инклюзивность",short:"Инклюзия",icon:"♿",v:4.1,pct:82},
    ],
    staff: ALL_STAFF.filter(s=>s.instId===1),
    address:"ул. Айни 14, район Сино, Душанбе 734001",
    phone:"+992 37 221-44-55",
    email:"info@sitorai-donish.tj",
    website:"sitorai-donish.tj",
    foodMenu:[
      {day:"Понедельник",meals:[
        {name:"Каша гречневая + чай",cal:"380 ккал",allergens:[]},
        {name:"Суп лапша куриный + лепёшка",cal:"520 ккал",allergens:["глютен"]},
        {name:"Плов + салат",cal:"680 ккал",allergens:[]},
      ]},
      {day:"Вторник",meals:[
        {name:"Яичница + хлеб + чай",cal:"420 ккал",allergens:["яйцо","глютен"]},
        {name:"Борщ + хлеб",cal:"490 ккал",allergens:["глютен"]},
        {name:"Курица жареная + рис + овощи",cal:"650 ккал",allergens:[]},
      ]},
    ],
  },
  {
    id:2, name:"Детский сад «Гулистон»", type:"Детсад", tk:"cat_kg",
    area:"Фирдавсӣ", price:650, score:4.3, rev:118,
    transport:true, food:true, halal:false, ver:true,
    color:C.red, age:"3–6 лет", tag:"Популярное",
    coverPhoto: PHOTOS.kindergarten,
    gallery:[
      {url:PHOTOS.kindergarten,label:"Площадка"},
      {url:PHOTOS.playground,label:"Игровой уголок"},
      {url:PHOTOS.classroom2,label:"Занятия"},
      {url:PHOTOS.library2,label:"Уголок чтения"},
    ],
    founded:2005, students:120,
    description:"Детский сад «Гулистон» — один из лучших частных садов района Фирдавсӣ. Работаем по методике развивающего обучения. Маленькие группы, внимательные педагоги, уютные игровые комнаты.",
    achievements:[
      {id:"kg1",title:"Лучший частный сад Душанбе",year:2023,category:"gold",desc:"По версии родительского рейтинга EduHub",type:"institution"},
      {id:"kg2",title:"Победа в городском конкурсе рисунков",year:2024,category:"silver",desc:"Группа 5-летних победила в городском конкурсе",type:"student"},
    ],
    metrics:[
      {label:"Качество обучения",short:"Обучение",icon:"📚",v:4.4,pct:88},
      {label:"Условия и помещения",short:"Условия",icon:"🏫",v:4.5,pct:90},
      {label:"Безопасность",short:"Безопасность",icon:"🔒",v:4.6,pct:92},
      {label:"Питание",short:"Питание",icon:"🍽",v:4.2,pct:84},
      {label:"Развозка",short:"Развозка",icon:"🚌",v:4.0,pct:80},
      {label:"Цена/качество",short:"Цена",icon:"💰",v:4.5,pct:90},
      {label:"Участие родителей",short:"Родители",icon:"👨‍👩‍👧",v:4.3,pct:86},
      {label:"Инклюзивность",short:"Инклюзия",icon:"♿",v:3.8,pct:76},
    ],
    staff: [],
    address:"ул. Рудаки 45а, район Фирдавсӣ, Душанбе",
    phone:"+992 93 888-22-33",
    email:"guiston.kg@gmail.com",
    website:"guiston-kg.tj",
  },
  {
    id:3, name:"Лицей при ТНУ", type:"Школа", tk:"cat_school",
    area:"И. Сомонӣ", price:1200, score:4.8, rev:301,
    transport:false, food:true, halal:true, ver:true,
    color:C.ok, age:"10–18 лет", tag:"Лучший рейтинг",
    coverPhoto: PHOTOS.school2,
    gallery:[
      {url:PHOTOS.school2,label:"Корпус"},
      {url:PHOTOS.classroom,label:"Аудитория"},
      {url:PHOTOS.library2,label:"Читальный зал"},
      {url:PHOTOS.university,label:"Кампус"},
      {url:PHOTOS.gym,label:"Спортзал"},
    ],
    founded:1993, students:620,
    description:"Лицей при ТНУ — привилегированное учебное заведение с углублённым изучением точных наук. Работаем в связке с Таджикским национальным университетом. Лучшие выпускники поступают в ведущие вузы России, Европы и Азии.",
    achievements:[
      {id:"tn1",title:"Топ-1 школа Таджикистана",year:2024,category:"gold",desc:"Национальный рейтинг по результатам ЕГЭ и олимпиад",type:"institution"},
      {id:"tn2",title:"7 медалистов республиканских олимпиад",year:2024,category:"gold",desc:"По математике, физике, химии, биологии",type:"student"},
      {id:"tn3",title:"Аккредитация IB Programme",year:2022,category:"special",desc:"Международный бакалавриат (IB) для 10–12 классов",type:"institution"},
    ],
    metrics:[
      {label:"Качество обучения",short:"Обучение",icon:"📚",v:4.9,pct:98},
      {label:"Условия и помещения",short:"Условия",icon:"🏫",v:4.7,pct:94},
      {label:"Безопасность",short:"Безопасность",icon:"🔒",v:4.8,pct:96},
      {label:"Питание",short:"Питание",icon:"🍽",v:4.6,pct:92},
      {label:"Развозка",short:"Развозка",icon:"🚌",v:3.5,pct:70},
      {label:"Цена/качество",short:"Цена",icon:"💰",v:4.3,pct:86},
      {label:"Участие родителей",short:"Родители",icon:"👨‍👩‍👧",v:4.7,pct:94},
      {label:"Инклюзивность",short:"Инклюзия",icon:"♿",v:4.2,pct:84},
    ],
    staff: [],
    address:"пр. Рудаки 17, район И. Сомонӣ, Душанбе",
    phone:"+992 37 227-00-10",
    email:"lyceum@tnu.tj",
    website:"lyceum.tnu.tj",
  },
  {
    id:4, name:"Центр «Форобиён»", type:"Центр", tk:"cat_center",
    area:"Шоҳмансур", price:400, score:4.1, rev:76,
    transport:false, food:false, halal:false, ver:false,
    color:"#C9A030", age:"любой", tag:null,
    coverPhoto: PHOTOS.classroom2,
    gallery:[{url:PHOTOS.classroom2,label:"Занятия"},{url:PHOTOS.student,label:"Урок"}],
    founded:2015, students:200,
    description:"Образовательный центр «Форобиён» — курсы английского, русского, математики и программирования для детей и взрослых. Занятия в малых группах (до 8 человек).",
    achievements:[
      {id:"fb1",title:"Лучший центр английского языка",year:2023,category:"silver",desc:"Рейтинг языковых курсов Душанбе",type:"institution"},
    ],
    metrics:[
      {label:"Качество обучения",short:"Обучение",icon:"📚",v:4.2,pct:84},
      {label:"Условия и помещения",short:"Условия",icon:"🏫",v:3.9,pct:78},
      {label:"Безопасность",short:"Безопасность",icon:"🔒",v:4.0,pct:80},
      {label:"Питание",short:"Питание",icon:"🍽",v:0,pct:0},
      {label:"Развозка",short:"Развозка",icon:"🚌",v:0,pct:0},
      {label:"Цена/качество",short:"Цена",icon:"💰",v:4.5,pct:90},
      {label:"Участие родителей",short:"Родители",icon:"👨‍👩‍👧",v:4.1,pct:82},
      {label:"Инклюзивность",short:"Инклюзия",icon:"♿",v:3.5,pct:70},
    ],
    staff: [],
    address:"ул. Зайниддин Сафаров 8, Шоҳмансур, Душанбе",
    phone:"+992 92 600-15-15",
    email:"forobyon@mail.ru",
    website:"forobyon.tj",
  },
  {
    id:5, name:"Языковая школа «Зафар»", type:"Центр", tk:"cat_center",
    area:"Сино", price:350, score:4.4, rev:95,
    transport:false, food:false, halal:false, ver:true,
    color:"#9B6FE0", age:"любой", tag:"Новинка",
    coverPhoto: PHOTOS.classroom,
    gallery:[{url:PHOTOS.classroom,label:"Класс"},{url:PHOTOS.student,label:"Занятие"}],
    founded:2021, students:180,
    description:"Языковая школа «Зафар» — современный центр изучения английского, китайского и арабского языков. Сертифицированные преподаватели, международные программы.",
    achievements:[
      {id:"zf1",title:"Аккредитация Cambridge Assessment",year:2023,category:"special",desc:"Официальный центр Cambridge English Exams",type:"institution"},
    ],
    metrics:[
      {label:"Качество обучения",short:"Обучение",icon:"📚",v:4.5,pct:90},
      {label:"Условия и помещения",short:"Условия",icon:"🏫",v:4.3,pct:86},
      {label:"Безопасность",short:"Безопасность",icon:"🔒",v:4.4,pct:88},
      {label:"Питание",short:"Питание",icon:"🍽",v:0,pct:0},
      {label:"Развозка",short:"Развозка",icon:"🚌",v:0,pct:0},
      {label:"Цена/качество",short:"Цена",icon:"💰",v:4.6,pct:92},
      {label:"Участие родителей",short:"Родители",icon:"👨‍👩‍👧",v:4.4,pct:88},
      {label:"Инклюзивность",short:"Инклюзия",icon:"♿",v:3.8,pct:76},
    ],
    staff: [],
    address:"пр. Саади Шерози 22, Сино, Душанбе",
    phone:"+992 98 700-22-22",
    email:"info@zafar.tj",
    website:"zafar.tj",
  },
  {
    id:6, name:"Мектаби нав «Дониш»", type:"Школа", tk:"cat_school",
    area:"Фирдавсӣ", price:950, score:4.2, rev:143,
    transport:true, food:true, halal:true, ver:true,
    color:"#2E9CDA", age:"7–17 лет", tag:null,
    coverPhoto: PHOTOS.school3,
    gallery:[
      {url:PHOTOS.school3,label:"Здание"},
      {url:PHOTOS.classroom,label:"Класс"},
      {url:PHOTOS.gym,label:"Спортзал"},
    ],
    founded:2010, students:560,
    description:"Мектаби нав «Дониш» — современная школа с акцентом на STEM-образование и цифровые технологии. Имеет оборудованную STEM-лабораторию и медиацентр.",
    achievements:[
      {id:"dn1",title:"Грант USAID — STEM-лаборатория",year:2022,category:"special",desc:"Полное оснащение лаборатории роботехники",type:"institution"},
      {id:"dn2",title:"Победа в городском хакатоне",year:2024,category:"gold",desc:"Команда учеников 9 класса заняла 1-е место",type:"student"},
    ],
    metrics:[
      {label:"Качество обучения",short:"Обучение",icon:"📚",v:4.3,pct:86},
      {label:"Условия и помещения",short:"Условия",icon:"🏫",v:4.4,pct:88},
      {label:"Безопасность",short:"Безопасность",icon:"🔒",v:4.5,pct:90},
      {label:"Питание",short:"Питание",icon:"🍽",v:4.1,pct:82},
      {label:"Развозка",short:"Развозка",icon:"🚌",v:4.0,pct:80},
      {label:"Цена/качество",short:"Цена",icon:"💰",v:4.2,pct:84},
      {label:"Участие родителей",short:"Родители",icon:"👨‍👩‍👧",v:4.3,pct:86},
      {label:"Инклюзивность",short:"Инклюзия",icon:"♿",v:4.0,pct:80},
    ],
    staff: [],
    address:"ул. Борбад 33, Фирдавсӣ, Душанбе",
    phone:"+992 37 235-00-50",
    email:"info@donish.tj",
    website:"donish.tj",
  },
];

// ── reviews ───────────────────────────────────────────────────────────────────
export const REVIEWS = [
  {id:"r1", name:"Саидахон М.",     init:"С", score:5, date:"Март 2026",    text:"Отличная школа — учителя внимательные, ребёнок с удовольствием ходит. Развозка вовремя, питание разнообразное.", reply:"Спасибо за доверие! Постоянно работаем над качеством.", instId:1},
  {id:"r2", name:"Фаррух Т.",       init:"Ф", score:4, date:"Февраль 2026", text:"Высокий уровень математики. Единственный минус — туалеты, но администрация решает.", reply:null, instId:1},
  {id:"r3", name:"Мадина О.",       init:"М", score:5, date:"Январь 2026",  text:"Дочь учится три года. Индивидуальный подход, клуб робототехники — просто отличные.", reply:"Рады видеть вашу дочь в нашей школьной семье!", instId:1},
  {id:"r4", name:"Хасан Р.",        init:"Х", score:5, date:"Март 2026",    text:"Лучший учитель физики в городе — Бахром Рустамович. Сын влюбился в физику!", reply:null, instId:1},
  {id:"r5", name:"Нилуфар Б.",      init:"Н", score:3, date:"Декабрь 2025", text:"Хорошая школа, но очереди в столовой раздражают. Надо больше мест.", reply:"Мы слышим вас и уже работаем над расширением столовой.", instId:1},
];

// ── news articles ─────────────────────────────────────────────────────────────
export const NEWS_ITEMS: NewsArticle[] = [
  {
    id:"n1", title:"Набор в 1-й класс на 2026/27 учебный год открыт!",
    category:"Объявление",
    coverUrl: PHOTOS.classroom2,
    content:"Уважаемые родители! Приём заявлений на 2026/27 учебный год открыт с 1 по 31 августа. Необходимо принести: свидетельство о рождении, медицинскую справку, фото 3×4 (2 шт). Запись по телефону или онлайн через сайт.",
    tags:["приём","2026-2027","1 класс"],
    date:"12 авг 2026", status:"published", views:1240,
  },
  {
    id:"n2", title:"Наши выпускники — призёры республиканской олимпиады!",
    category:"Достижение",
    coverUrl: PHOTOS.student,
    videoUrl:"",
    content:"Гордимся нашими учениками! В этом году трое выпускников заняли призовые места: Санги Давлатов — золото по математике, Зуhra Каримова — серебро по химии, Бобур Рахимов — бронза по физике.",
    tags:["олимпиада","победа","математика"],
    date:"5 июл 2026", status:"published", views:3450,
  },
  {
    id:"n3", title:"Ремонт спортивного зала завершён",
    category:"Новость",
    coverUrl: PHOTOS.gym,
    content:"В рамках летнего ремонта спортивный зал полностью обновлён: новое покрытие, современный инвентарь, LED-освещение. С 1 сентября занятия ФК и секции возобновляются.",
    tags:["ремонт","спортзал","инфраструктура"],
    date:"20 июн 2026", status:"published", views:890,
  },
  {
    id:"n4", title:"День открытых дверей — 20 августа",
    category:"Мероприятие",
    coverUrl: PHOTOS.school1,
    content:"Приглашаем всех желающих на день открытых дверей 20 августа в 10:00. Вы сможете познакомиться с педагогами, осмотреть классы и задать вопросы администрации.",
    tags:["день открытых дверей","мероприятие"],
    date:"10 авг 2026", status:"draft", views:0,
  },
];

// ── messages ──────────────────────────────────────────────────────────────────
export const MESSAGES: {id:number;convId:number;from:"me"|"inst";text:string;time:string}[] = [
  {id:1, convId:1, from:"inst", text:"Здравствуйте! Чем могу помочь?",                                 time:"10:13"},
  {id:2, convId:1, from:"me",   text:"Здравствуйте! Есть ли места в 5-й класс?",                      time:"10:14"},
  {id:3, convId:1, from:"inst", text:"Добрый день! Есть. Приём заявок до 1 мая.",                      time:"10:16"},
  {id:4, convId:1, from:"me",   text:"Онлайн удобнее. Какие документы нужны?",                         time:"10:18"},
  {id:5, convId:1, from:"inst", text:"Паспорт родителя, свидетельство о рождении, справка и медкарта.", time:"10:20"},
  {id:6, convId:1, from:"me",   text:"Отлично, жду письмо!",                                           time:"10:22"},
  {id:7, convId:2, from:"inst", text:"Добрый день! Запись подтверждена.",                               time:"09:00"},
  {id:8, convId:3, from:"inst", text:"Пришлите документы до пятницы.",                                 time:"Вт"},
];

export const CONVS: {id:number;name:string;color:string;unread:number;instId:number}[] = [
  {id:1, name:"Гимназия «Ситораи Дониш»", color:C.teal, unread:0, instId:1},
  {id:2, name:"Детский сад «Гулистон»",   color:C.red,  unread:2, instId:2},
  {id:3, name:"Лицей при ТНУ",            color:C.ok,   unread:0, instId:3},
];
