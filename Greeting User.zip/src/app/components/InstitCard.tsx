import { useState } from "react";
import { MapPin, GraduationCap, Baby, Layers, CheckCircle, Heart, BarChart2, ArrowRight } from "lucide-react";
import { C, FH, FB, Institution } from "../data";

function Stars({ s, size=12 }:{s:number;size?:number}) {
  return (
    <span style={{display:"flex",gap:2}}>
      {[1,2,3,4,5].map(i=>(
        <svg key={i} width={size} height={size} viewBox="0 0 24 24" fill={i<=Math.round(s)?C.gold:C.dim}>
          <path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/>
        </svg>
      ))}
    </span>
  );
}

export function InstitCard({ inst, onClick, onCompare }: {
  inst: Institution;
  onClick: ()=>void;
  onCompare?: ()=>void;
}) {
  const [hov,setHov] = useState(false);
  const [saved,setSaved] = useState(false);

  const TypeIcon = inst.tk==="cat_kg" ? Baby : inst.tk==="cat_school" ? GraduationCap : Layers;

  return (
    <div onClick={onClick}
      onMouseEnter={()=>setHov(true)} onMouseLeave={()=>setHov(false)}
      style={{borderRadius:18,overflow:"hidden",cursor:"pointer",background:C.s1,border:`1px solid ${hov?inst.color+"55":C.border}`,transition:"all .22s",transform:hov?"translateY(-4px)":"none",boxShadow:hov?`0 20px 50px rgba(0,0,0,.5)`:undefined}}>

      {/* cover photo */}
      <div style={{height:170,position:"relative",overflow:"hidden",background:inst.color}}>
        <img src={inst.coverPhoto} alt={inst.name} style={{width:"100%",height:"100%",objectFit:"cover",transition:"transform .3s",transform:hov?"scale(1.05)":"scale(1)"}}/>
        <div style={{position:"absolute",inset:0,background:`linear-gradient(180deg,rgba(0,0,0,.15) 0%,rgba(0,0,0,.55) 100%)`}}/>

        {/* tag */}
        {inst.tag && <span style={{position:"absolute",top:12,left:12,fontSize:11,fontWeight:800,fontFamily:FH,padding:"4px 10px",borderRadius:8,background:C.gold,color:C.bg}}>{inst.tag}</span>}

        {/* save */}
        <button onClick={e=>{e.stopPropagation();setSaved(!saved)}} style={{position:"absolute",top:10,right:10,width:32,height:32,borderRadius:"50%",background:"rgba(0,0,0,.4)",border:`1px solid rgba(255,255,255,.2)`,display:"flex",alignItems:"center",justifyContent:"center"}}>
          <Heart size={13} fill={saved?C.red:"none"} stroke={saved?C.red:"#fff"}/>
        </button>

        {/* bottom meta */}
        <div style={{position:"absolute",bottom:12,left:12,display:"flex",alignItems:"center",gap:7}}>
          <div style={{width:34,height:34,borderRadius:9,background:"rgba(255,255,255,.15)",backdropFilter:"blur(8px)",display:"flex",alignItems:"center",justifyContent:"center"}}>
            <TypeIcon size={17} color="#fff"/>
          </div>
          <div>
            <p style={{fontSize:10.5,fontWeight:700,color:"rgba(255,255,255,.65)",fontFamily:FH,textTransform:"uppercase",letterSpacing:".05em"}}>{inst.type}</p>
            <p style={{fontSize:12,fontWeight:600,color:"#fff",fontFamily:FH}}>{inst.area}</p>
          </div>
        </div>
      </div>

      <div style={{padding:"16px 16px 18px"}}>
        <h3 style={{fontFamily:FH,fontWeight:800,fontSize:15.5,lineHeight:1.3,color:C.text,marginBottom:8,minHeight:40}}>{inst.name}</h3>

        <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:10}}>
          <Stars s={inst.score}/>
          <span style={{fontFamily:FH,fontWeight:700,fontSize:12.5,color:C.text}}>{inst.score}</span>
          <span style={{fontSize:12,color:C.muted}}>({inst.rev})</span>
          {inst.ver && <span style={{marginLeft:"auto",fontSize:10.5,fontWeight:700,color:C.ok,display:"flex",alignItems:"center",gap:3}}><CheckCircle size={10}/> МОН</span>}
        </div>

        <div style={{display:"flex",flexWrap:"wrap",gap:5,marginBottom:13}}>
          {inst.transport && <span style={{fontSize:10.5,fontWeight:600,padding:"3px 8px",borderRadius:6,background:`${C.teal}18`,color:C.teal,fontFamily:FH}}>🚌 Развозка</span>}
          {inst.food      && <span style={{fontSize:10.5,fontWeight:600,padding:"3px 8px",borderRadius:6,background:`${C.gold}18`,color:C.gold,fontFamily:FH}}>🍽 Питание</span>}
          {inst.halal     && <span style={{fontSize:10.5,fontWeight:600,padding:"3px 8px",borderRadius:6,background:`${C.red}18`,color:"#E87060",fontFamily:FH}}>☪ Халяль</span>}
        </div>

        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",paddingTop:12,borderTop:`1px solid ${C.border}`}}>
          <div>
            <span style={{fontFamily:FH,fontWeight:900,fontSize:20,color:C.text}}>{inst.price}</span>
            <span style={{fontSize:11.5,color:C.muted,marginLeft:3}}>сом/мес</span>
          </div>
          <button onClick={e=>{e.stopPropagation();onCompare?.()}} style={{display:"flex",alignItems:"center",gap:4,fontFamily:FH,fontWeight:700,fontSize:12,padding:"6px 12px",borderRadius:8,background:hov?`${inst.color}30`:C.s3,color:hov?inst.color:C.sub,transition:"all .2s"}}>
            <BarChart2 size={12}/> Сравнить
          </button>
        </div>
      </div>
    </div>
  );
}
