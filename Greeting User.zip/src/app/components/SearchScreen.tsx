import { useState } from "react";
import { Search, SlidersHorizontal, ChevronDown, X } from "lucide-react";
import { C, FH, FB, INSTITUTIONS } from "../data";
import { InstitCard } from "./InstitCard";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";

type SortKey = "score"|"price_asc"|"price_desc"|"reviews";

export function SearchScreen({ set, setInstId }: { set:(s:Screen)=>void; setInstId:(id:number)=>void }) {
  const [q,        setQ]        = useState("");
  const [typeF,    setTypeF]    = useState<string|null>(null);
  const [areaF,    setAreaF]    = useState<string[]>([]);
  const [minPrice, setMinPrice] = useState(0);
  const [maxPrice, setMaxPrice] = useState(2000);
  const [ratingF,  setRatingF]  = useState(0);
  const [transF,   setTransF]   = useState(false);
  const [foodF,    setFoodF]    = useState(false);
  const [halalF,   setHalalF]   = useState(false);
  const [verF,     setVerF]     = useState(false);
  const [sort,     setSort]     = useState<SortKey>("score");
  const [showFilters, setShowFilters] = useState(true);

  const toggleArea = (a:string) =>
    setAreaF(prev => prev.includes(a) ? prev.filter(x=>x!==a) : [...prev, a]);

  const activeCount = [typeF,areaF.length>0,ratingF>0,transF,foodF,halalF,verF,minPrice>0,maxPrice<2000].filter(Boolean).length;

  const clearAll = () => { setTypeF(null); setAreaF([]); setRatingF(0); setTransF(false); setFoodF(false); setHalalF(false); setVerF(false); setMinPrice(0); setMaxPrice(2000); };

  let results = INSTITUTIONS.filter(i => {
    if(q && !i.name.toLowerCase().includes(q.toLowerCase()) && !i.type.toLowerCase().includes(q.toLowerCase())) return false;
    if(typeF   && i.tk!==typeF)         return false;
    if(areaF.length>0 && !areaF.includes(i.area)) return false;
    if(i.score < ratingF)              return false;
    if(i.price < minPrice || i.price > maxPrice) return false;
    if(transF  && !i.transport)        return false;
    if(foodF   && !i.food)             return false;
    if(halalF  && !i.halal)            return false;
    if(verF    && !i.ver)              return false;
    return true;
  });

  if(sort==="score")      results = [...results].sort((a,b)=>b.score-a.score);
  if(sort==="price_asc")  results = [...results].sort((a,b)=>a.price-b.price);
  if(sort==="price_desc") results = [...results].sort((a,b)=>b.price-a.price);
  if(sort==="reviews")    results = [...results].sort((a,b)=>b.rev-a.rev);

  // ── sub-components ──────────────────────────────────────────────────────────
  function Chip({l,on,click}:{l:string;on:boolean;click:()=>void}) {
    return (
      <button onClick={click} style={{fontSize:12.5,fontWeight:600,padding:"6px 12px",borderRadius:8,border:`1px solid ${on?C.teal:C.border}`,background:on?`${C.teal}22`:"transparent",color:on?C.teal:C.sub,transition:"all .13s",fontFamily:FH,whiteSpace:"nowrap"}}>
        {l}
      </button>
    );
  }

  function Toggle({l,v,fn,color=C.ok}:{l:string;v:boolean;fn:()=>void;color?:string}) {
    return (
      <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",fontSize:13.5,color:v?C.text:C.sub,padding:"6px 0",fontFamily:FB}}>
        <span>{l}</span>
        <button onClick={fn} style={{width:40,height:22,borderRadius:999,position:"relative",background:v?color:C.s3,transition:"background .18s",flexShrink:0}}>
          <span style={{position:"absolute",top:3,width:16,height:16,borderRadius:"50%",background:"#fff",transition:"left .18s",left:v?21:3,boxShadow:"0 1px 3px rgba(0,0,0,.3)"}}/>
        </button>
      </div>
    );
  }

  function SectionLabel({l}:{l:string}) {
    return <p style={{fontSize:11,fontWeight:700,textTransform:"uppercase",letterSpacing:".08em",color:C.dim,marginBottom:10,fontFamily:FH}}>{l}</p>;
  }

  function Divider() {
    return <div style={{borderTop:`1px solid ${C.border}`,margin:"14px 0"}}/>;
  }

  return (
    <div style={{maxWidth:1260,margin:"0 auto",padding:"28px 28px 72px"}}>
      {/* top bar */}
      <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:20}}>
        {/* search input */}
        <div style={{flex:1,display:"flex",alignItems:"center",gap:10,background:C.s1,border:`1px solid ${C.border}`,borderRadius:12,padding:"11px 16px"}}>
          <Search size={16} style={{color:C.teal,flexShrink:0}}/>
          <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Поиск по названию или типу…"
            style={{flex:1,background:"transparent",border:"none",outline:"none",fontSize:14.5,color:C.text,fontFamily:FB}}/>
          {q && <button onClick={()=>setQ("")}><X size={15} style={{color:C.muted}}/></button>}
        </div>
        {/* filter toggle */}
        <button onClick={()=>setShowFilters(!showFilters)}
          style={{display:"flex",alignItems:"center",gap:7,padding:"11px 16px",borderRadius:12,fontFamily:FH,fontWeight:700,fontSize:13.5,border:`1px solid ${activeCount>0?C.teal:C.border}`,background:activeCount>0?`${C.teal}18`:"transparent",color:activeCount>0?C.teal:C.sub,transition:"all .14s"}}>
          <SlidersHorizontal size={15}/>
          Фильтры
          {activeCount>0 && <span style={{background:C.teal,color:C.bg,borderRadius:"50%",width:18,height:18,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:800}}>{activeCount}</span>}
        </button>
        {/* sort */}
        <div style={{position:"relative"}}>
          <select value={sort} onChange={e=>setSort(e.target.value as SortKey)}
            style={{appearance:"none",padding:"11px 36px 11px 14px",borderRadius:12,border:`1px solid ${C.border}`,background:C.s1,color:C.text,fontFamily:FH,fontWeight:600,fontSize:13.5,outline:"none",cursor:"pointer"}}>
            <option value="score">По рейтингу</option>
            <option value="price_asc">Дешевле сначала</option>
            <option value="price_desc">Дороже сначала</option>
            <option value="reviews">По отзывам</option>
          </select>
          <ChevronDown size={14} style={{position:"absolute",right:12,top:"50%",transform:"translateY(-50%)",color:C.muted,pointerEvents:"none"}}/>
        </div>
        {/* results count */}
        <span style={{fontFamily:FB,fontSize:14,color:C.muted,whiteSpace:"nowrap"}}>
          <b style={{color:C.text}}>{results.length}</b> учреждений
        </span>
      </div>

      <div style={{display:"grid",gridTemplateColumns:showFilters?"250px 1fr":"1fr",gap:22,alignItems:"start"}}>
        {/* ── SIDEBAR FILTERS ── */}
        {showFilters && (
          <aside style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,position:"sticky",top:80,alignSelf:"start",overflow:"hidden"}}>
            <div style={{padding:"16px 18px",borderBottom:`1px solid ${C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center"}}>
              <span style={{fontFamily:FH,fontWeight:800,fontSize:16,color:C.text}}>Фильтры</span>
              {activeCount>0 && <button onClick={clearAll} style={{fontSize:12.5,fontWeight:600,color:C.red,fontFamily:FH}}>Сбросить</button>}
            </div>

            <div style={{padding:"16px 18px",maxHeight:"calc(100vh - 200px)",overflowY:"auto"}}>
              {/* Type */}
              <SectionLabel l="Тип учреждения"/>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
                {[{k:"cat_kg",l:"🧒 Детсады"},{k:"cat_school",l:"🎓 Школы"},{k:"cat_center",l:"📖 Центры"},{k:"cat_uni",l:"🏛 Вузы"}].map(({k,l})=>(
                  <Chip key={k} l={l} on={typeF===k} click={()=>setTypeF(typeF===k?null:k)}/>
                ))}
              </div>

              <Divider/>

              {/* Area */}
              <SectionLabel l="Район"/>
              <div style={{display:"flex",flexWrap:"wrap",gap:6}}>
                {["Сино","Фирдавсӣ","И. Сомонӣ","Шоҳмансур"].map(a=>(
                  <Chip key={a} l={a} on={areaF.includes(a)} click={()=>toggleArea(a)}/>
                ))}
              </div>

              <Divider/>

              {/* Price range */}
              <SectionLabel l="Стоимость в месяц (сом)"/>
              <div style={{marginBottom:8}}>
                <div style={{display:"flex",justifyContent:"space-between",fontSize:13,color:C.sub,fontFamily:FB,marginBottom:8}}>
                  <span>{minPrice === 0 ? "Бесплатно" : `${minPrice} сом`}</span>
                  <span>{maxPrice >= 2000 ? "Любая" : `${maxPrice} сом`}</span>
                </div>
                <div style={{position:"relative",height:4,borderRadius:999,background:C.s3}}>
                  <div style={{position:"absolute",left:`${minPrice/20}%`,right:`${(2000-maxPrice)/20}%`,height:"100%",background:C.teal,borderRadius:999}}/>
                </div>
                <div style={{display:"flex",gap:8,marginTop:10}}>
                  <input type="range" min={0} max={1900} step={50} value={minPrice} onChange={e=>setMinPrice(+e.target.value)}
                    style={{flex:1,accentColor:C.teal}}/>
                  <input type="range" min={100} max={2000} step={50} value={maxPrice} onChange={e=>setMaxPrice(+e.target.value)}
                    style={{flex:1,accentColor:C.teal}}/>
                </div>
              </div>

              <Divider/>

              {/* Rating */}
              <SectionLabel l="Минимальный рейтинг"/>
              <div style={{display:"flex",gap:6}}>
                {[0,3.5,4.0,4.5].map(r=>(
                  <Chip key={r} l={r===0?"Любой":`${r}★`} on={ratingF===r} click={()=>setRatingF(r)}/>
                ))}
              </div>

              <Divider/>

              {/* Toggles */}
              <SectionLabel l="Дополнительно"/>
              <div style={{display:"flex",flexDirection:"column",gap:4}}>
                <Toggle l="Есть развозка"      v={transF} fn={()=>setTransF(!transF)} color={C.teal}/>
                <Toggle l="Есть питание"        v={foodF}  fn={()=>setFoodF(!foodF)}  color={C.gold}/>
                <Toggle l="Халяльное питание"   v={halalF} fn={()=>setHalalF(!halalF)} color={C.red}/>
                <Toggle l="Проверено МОН РТ"    v={verF}   fn={()=>setVerF(!verF)}    color={C.ok}/>
              </div>
            </div>
          </aside>
        )}

        {/* ── RESULTS ── */}
        <div>
          {/* active filter chips */}
          {activeCount>0 && (
            <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:14}}>
              {typeF && <ActiveChip l={typeF==="cat_kg"?"Детсады":typeF==="cat_school"?"Школы":typeF==="cat_center"?"Центры":"Вузы"} clear={()=>setTypeF(null)}/>}
              {areaF.map(a=><ActiveChip key={a} l={a} clear={()=>toggleArea(a)}/>)}
              {ratingF>0 && <ActiveChip l={`${ratingF}★+`} clear={()=>setRatingF(0)}/>}
              {transF && <ActiveChip l="Развозка" clear={()=>setTransF(false)}/>}
              {foodF  && <ActiveChip l="Питание"  clear={()=>setFoodF(false)}/>}
              {halalF && <ActiveChip l="Халяль"   clear={()=>setHalalF(false)}/>}
              {verF   && <ActiveChip l="МОН"      clear={()=>setVerF(false)}/>}
            </div>
          )}

          {results.length===0 ? (
            <div style={{padding:56,borderRadius:16,border:`1px dashed ${C.border}`,textAlign:"center",color:C.muted}}>
              <Search size={32} style={{color:C.dim,margin:"0 auto 12px"}}/>
              <p style={{fontFamily:FH,fontWeight:800,fontSize:18,color:C.text,marginBottom:6}}>Ничего не найдено</p>
              <p style={{fontFamily:FB,fontSize:14}}>Попробуйте изменить фильтры</p>
              {activeCount>0 && <button onClick={clearAll} style={{marginTop:12,padding:"9px 20px",borderRadius:10,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:700,fontSize:13.5}}>Сбросить фильтры</button>}
            </div>
          ) : (
            <div style={{display:"grid",gridTemplateColumns:showFilters?"1fr 1fr":"repeat(3,1fr)",gap:18}}>
              {results.map(inst=>(
                <InstitCard key={inst.id} inst={inst} onClick={()=>{setInstId(inst.id);set("profile")}} onCompare={()=>set("compare")}/>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ActiveChip({l,clear}:{l:string;clear:()=>void}) {
  return (
    <span style={{display:"inline-flex",alignItems:"center",gap:5,fontSize:12.5,fontWeight:600,padding:"4px 10px",borderRadius:8,background:`${C.teal}20`,color:C.teal,fontFamily:FH}}>
      {l} <button onClick={clear} style={{display:"flex",alignItems:"center"}}><X size={12}/></button>
    </span>
  );
}
