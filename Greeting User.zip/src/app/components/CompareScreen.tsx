import { useState } from "react";
import { Check, X, ArrowRight, ChevronLeft, BarChart2 } from "lucide-react";
import { RadarChart, PolarGrid, PolarAngleAxis, Radar, ResponsiveContainer, Legend } from "recharts";
import { C, FH, FB, INSTITUTIONS, Institution } from "../data";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";

const TYPE_LABELS: Record<string,string> = {cat_kg:"Детсады",cat_school:"Школы",cat_center:"Учебные центры",cat_uni:"Вузы"};
const RADAR_COLORS = [C.teal, C.gold, C.red, "#A78BFA"];

function Stars({ s }:{s:number}) {
  return <span style={{display:"flex",gap:2,alignItems:"center"}}>{[1,2,3,4,5].map(i=>(<svg key={i} width={11} height={11} viewBox="0 0 24 24" fill={i<=Math.round(s)?C.gold:C.dim}><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>))}</span>;
}

export function CompareScreen({ set, setInstId }: { set:(s:Screen)=>void; setInstId:(id:number)=>void }) {
  const [step,     setStep]     = useState(1);
  const [typeKey,  setTypeKey]  = useState<string|null>(null);
  const [selected, setSelected] = useState<number[]>([]);

  const typeGroups = Object.keys(TYPE_LABELS);
  const filtered   = typeKey ? INSTITUTIONS.filter(i=>i.tk===typeKey) : [];

  function toggleSelect(id:number) {
    setSelected(prev => prev.includes(id) ? prev.filter(x=>x!==id) : prev.length<4 ? [...prev,id] : prev);
  }

  const compareList = selected.map(id=>INSTITUTIONS.find(i=>i.id===id)!).filter(Boolean);

  const radarData = (compareList[0]?.metrics ?? []).map(m=>({
    axis: m.label,
    ...Object.fromEntries(compareList.map((inst,ci)=>[`v${ci}`, (inst.metrics?.find(x=>x.label===m.label)?.v ?? 0)]))
  }));

  function Step1() {
    return (
      <div style={{maxWidth:700,margin:"0 auto",padding:"56px 28px",textAlign:"center"}}>
        <div style={{display:"inline-flex",alignItems:"center",gap:7,padding:"6px 14px",borderRadius:999,border:`1px solid ${C.teal}44`,background:`${C.teal}12`,marginBottom:22}}>
          <BarChart2 size={13} style={{color:C.teal}}/>
          <span style={{fontSize:12.5,fontWeight:700,color:C.teal,fontFamily:FH}}>Умное сравнение · Шаг 1 из 3</span>
        </div>
        <h1 style={{fontFamily:FH,fontWeight:900,fontSize:"clamp(28px,4vw,42px)",color:C.text,marginBottom:10,lineHeight:1.1}}>
          Выберите тип<br/>учреждения
        </h1>
        <p style={{fontSize:15,color:C.sub,marginBottom:40}}>Сравнение работает внутри одного типа для точных результатов</p>
        <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14,maxWidth:480,margin:"0 auto"}}>
          {typeGroups.map(k=>{
            const count = INSTITUTIONS.filter(i=>i.tk===k).length;
            const icons: Record<string,string> = {cat_kg:"🧒",cat_school:"🎓",cat_center:"📖",cat_uni:"🏛"};
            return (
              <button key={k} onClick={()=>{setTypeKey(k);setStep(2)}}
                style={{padding:"26px 20px",borderRadius:18,border:`2px solid ${typeKey===k?C.teal:C.border}`,background:typeKey===k?`${C.teal}15`:C.s1,cursor:"pointer",textAlign:"left",transition:"all .18s"}}>
                <span style={{fontSize:40,display:"block",marginBottom:10}}>{icons[k]}</span>
                <p style={{fontFamily:FH,fontWeight:800,fontSize:17,color:C.text,marginBottom:4}}>{TYPE_LABELS[k]}</p>
                <p style={{fontSize:12.5,color:C.sub}}>{count} учреждений</p>
              </button>
            );
          })}
        </div>
      </div>
    );
  }

  function Step2() {
    return (
      <div style={{maxWidth:1100,margin:"0 auto",padding:"40px 28px"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:32}}>
          <button onClick={()=>setStep(1)} style={{display:"flex",alignItems:"center",gap:6,padding:"8px 14px",borderRadius:9,border:`1px solid ${C.border}`,color:C.muted,fontFamily:FH,fontWeight:600,fontSize:13}}>
            <ChevronLeft size={14}/> Назад
          </button>
          <div>
            <div style={{fontSize:11.5,fontWeight:700,color:C.teal,fontFamily:FH,textTransform:"uppercase",letterSpacing:".06em",marginBottom:2}}>Шаг 2 из 3 · {TYPE_LABELS[typeKey!]}</div>
            <h2 style={{fontFamily:FH,fontWeight:900,fontSize:24,color:C.text}}>Выберите 2–4 учреждения</h2>
          </div>
          {selected.length>=2 && (
            <button onClick={()=>setStep(3)} style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:7,padding:"11px 22px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14}}>
              Сравнить <ArrowRight size={15}/>
            </button>
          )}
        </div>

        {/* selected badges */}
        {selected.length>0 && (
          <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:20,padding:"14px 16px",borderRadius:14,background:C.s1,border:`1px solid ${C.teal}33`}}>
            <span style={{fontSize:13,color:C.teal,fontFamily:FH,fontWeight:700,alignSelf:"center"}}>Выбрано:</span>
            {compareList.map(inst=>(
              <span key={inst.id} style={{display:"inline-flex",alignItems:"center",gap:6,padding:"5px 12px",borderRadius:8,background:`${C.teal}20`,color:C.teal,fontFamily:FH,fontWeight:600,fontSize:13}}>
                {inst.name}
                <button onClick={()=>toggleSelect(inst.id)}><X size={12}/></button>
              </span>
            ))}
            <span style={{marginLeft:"auto",fontSize:13,color:C.muted,alignSelf:"center"}}>{selected.length}/4</span>
          </div>
        )}

        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:16}}>
          {filtered.map(inst=>{
            const on = selected.includes(inst.id);
            return (
              <div key={inst.id} onClick={()=>toggleSelect(inst.id)}
                style={{borderRadius:18,overflow:"hidden",border:`2px solid ${on?C.teal:C.border}`,background:on?`${C.teal}10`:C.s1,cursor:"pointer",transition:"all .18s",position:"relative"}}>
                {on && <div style={{position:"absolute",top:12,right:12,zIndex:2,width:26,height:26,borderRadius:"50%",background:C.teal,display:"flex",alignItems:"center",justifyContent:"center"}}><Check size={14} color={C.bg}/></div>}
                <div style={{height:140,overflow:"hidden"}}>
                  <img src={inst.coverPhoto} alt={inst.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                </div>
                <div style={{padding:"14px 16px"}}>
                  <p style={{fontFamily:FH,fontWeight:800,fontSize:15,color:C.text,marginBottom:6}}>{inst.name}</p>
                  <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:6}}>
                    <Stars s={inst.score}/>
                    <span style={{fontSize:12,color:C.muted}}>({inst.rev})</span>
                  </div>
                  <div style={{display:"flex",justifyContent:"space-between",fontSize:13.5,color:C.sub}}>
                    <span>{inst.area}</span>
                    <span style={{fontFamily:FH,fontWeight:700,color:C.text}}>{inst.price} сом</span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  function Step3() {
    return (
      <div style={{maxWidth:1200,margin:"0 auto",padding:"40px 28px 80px"}}>
        <div style={{display:"flex",alignItems:"center",gap:12,marginBottom:32}}>
          <button onClick={()=>setStep(2)} style={{display:"flex",alignItems:"center",gap:6,padding:"8px 14px",borderRadius:9,border:`1px solid ${C.border}`,color:C.muted,fontFamily:FH,fontWeight:600,fontSize:13}}>
            <ChevronLeft size={14}/> Изменить выбор
          </button>
          <div>
            <div style={{fontSize:11.5,fontWeight:700,color:C.teal,fontFamily:FH,textTransform:"uppercase",letterSpacing:".06em",marginBottom:2}}>Шаг 3 из 3 · Результаты</div>
            <h2 style={{fontFamily:FH,fontWeight:900,fontSize:24,color:C.text}}>Сравнение учреждений</h2>
          </div>
        </div>

        {/* inst headers */}
        <div style={{display:"grid",gridTemplateColumns:`200px repeat(${compareList.length},1fr)`,gap:14,marginBottom:20}}>
          <div/>
          {compareList.map((inst,ci)=>(
            <div key={inst.id} style={{borderRadius:16,overflow:"hidden",border:`2px solid ${RADAR_COLORS[ci]}44`,background:C.s1}}>
              <div style={{height:120,overflow:"hidden",position:"relative"}}>
                <img src={inst.coverPhoto} alt={inst.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                <div style={{position:"absolute",inset:0,background:`linear-gradient(180deg,transparent 40%,rgba(7,24,26,.9) 100%)`}}/>
                <div style={{position:"absolute",bottom:0,left:0,right:0,padding:"0 12px 10px"}}>
                  <div style={{width:"100%",height:3,borderRadius:999,background:RADAR_COLORS[ci],marginBottom:6}}/>
                  <p style={{fontFamily:FH,fontWeight:800,fontSize:13.5,color:C.text,lineHeight:1.2}}>{inst.name}</p>
                </div>
              </div>
              <div style={{padding:"10px 12px"}}>
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <Stars s={inst.score}/>
                  <span style={{fontFamily:FH,fontWeight:700,fontSize:13,color:C.text}}>{inst.score}</span>
                </div>
                <p style={{fontSize:12.5,color:C.sub,marginTop:4}}>{inst.area}</p>
                <p style={{fontFamily:FH,fontWeight:800,fontSize:16,color:RADAR_COLORS[ci],marginTop:6}}>{inst.price} <span style={{fontSize:11,fontWeight:400,color:C.muted}}>сом/мес</span></p>
                <button onClick={()=>{setInstId(inst.id);set("profile")}}
                  style={{marginTop:8,width:"100%",padding:"7px",borderRadius:8,border:`1px solid ${RADAR_COLORS[ci]}44`,color:RADAR_COLORS[ci],fontFamily:FH,fontWeight:700,fontSize:12,background:`${RADAR_COLORS[ci]}10`,transition:"all .14s"}}>
                  Открыть профиль
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Radar chart */}
        {radarData.length>0 && (
          <div style={{borderRadius:20,border:`1px solid ${C.border}`,background:C.s1,padding:"28px 24px",marginBottom:24}}>
            <h3 style={{fontFamily:FH,fontWeight:800,fontSize:17,color:C.text,marginBottom:6}}>Радарная диаграмма</h3>
            <p style={{fontSize:13,color:C.sub,marginBottom:20}}>Сравнение по ключевым параметрам</p>
            <ResponsiveContainer width="100%" height={340}>
              <RadarChart data={radarData}>
                <PolarGrid stroke={C.s3}/>
                <PolarAngleAxis dataKey="axis" tick={{fill:C.sub, fontSize:12, fontFamily:FB}}/>
                {compareList.map((_,ci)=>(
                  <Radar key={ci} name={compareList[ci].name} dataKey={`v${ci}`}
                    stroke={RADAR_COLORS[ci]} fill={RADAR_COLORS[ci]} fillOpacity={0.15}/>
                ))}
                <Legend wrapperStyle={{fontSize:13,fontFamily:FH}}/>
              </RadarChart>
            </ResponsiveContainer>
          </div>
        )}

        {/* Comparison rows */}
        <div style={{borderRadius:20,border:`1px solid ${C.border}`,background:C.s1,overflow:"hidden"}}>
          <div style={{padding:"16px 20px",borderBottom:`1px solid ${C.border}`,background:C.s2}}>
            <h3 style={{fontFamily:FH,fontWeight:800,fontSize:16,color:C.text}}>Детальное сравнение</h3>
          </div>
          {[
            {label:"Рейтинг",    render:(i:Institution)=><div style={{display:"flex",gap:6,alignItems:"center"}}><Stars s={i.score}/><b style={{color:C.text,fontFamily:FH}}>{i.score}</b></div>},
            {label:"Стоимость",  render:(i:Institution)=><b style={{color:C.gold,fontFamily:FH,fontSize:15}}>{i.price} сом</b>},
            {label:"Район",      render:(i:Institution)=><span style={{color:C.sub,fontSize:13.5}}>{i.area}</span>},
            {label:"Отзывов",    render:(i:Institution)=><span style={{color:C.sub}}>{i.rev}</span>},
            {label:"МОН РТ",     render:(i:Institution)=><span style={{color:i.ver?C.ok:C.muted}}>{i.ver?"✓ Да":"✗ Нет"}</span>},
            {label:"Транспорт",  render:(i:Institution)=><span style={{color:i.transport?C.teal:C.muted}}>{i.transport?"✓ Есть":"✗ Нет"}</span>},
            {label:"Питание",    render:(i:Institution)=><span style={{color:i.food?C.gold:C.muted}}>{i.food?"✓ Есть":"✗ Нет"}</span>},
            {label:"Халяль",     render:(i:Institution)=><span style={{color:i.halal?"#E87060":C.muted}}>{i.halal?"✓ Есть":"✗ Нет"}</span>},
          ].map((row,ri)=>(
            <div key={row.label} style={{display:"grid",gridTemplateColumns:`200px repeat(${compareList.length},1fr)`,gap:14,padding:"14px 20px",background:ri%2===0?"transparent":C.s2,borderBottom:`1px solid ${C.border}`}}>
              <span style={{fontSize:13.5,fontFamily:FH,fontWeight:700,color:C.muted,alignSelf:"center"}}>{row.label}</span>
              {compareList.map(inst=>(
                <div key={inst.id} style={{alignSelf:"center"}}>{row.render(inst)}</div>
              ))}
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div>
      {step===1 && <Step1/>}
      {step===2 && typeKey && <Step2/>}
      {step===3 && compareList.length>=2 && <Step3/>}
    </div>
  );
}
