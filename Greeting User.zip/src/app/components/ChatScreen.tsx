import { useState } from "react";
import { Send, Search, MoreHorizontal, Phone, Video, Paperclip, Smile } from "lucide-react";
import { C, FH, FB, CONVS, MESSAGES } from "../data";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";

export function ChatScreen({ set }: { set:(s:Screen)=>void }) {
  const [activeConv, setActiveConv] = useState(CONVS[0]?.id ?? 0);
  const [msgText,    setMsgText]    = useState("");
  const [messages,   setMessages]   = useState(MESSAGES);
  const [mode,       setMode]       = useState<"user"|"institution">("user");

  const conv = CONVS.find(c=>c.id===activeConv);
  const convMessages = messages.filter(m=>m.convId===activeConv);

  function send() {
    if(!msgText.trim()) return;
    setMessages(prev=>[...prev,{
      id: Date.now(),
      convId: activeConv,
      from: mode==="user"?"me":"inst",
      text: msgText.trim(),
      time: new Date().toLocaleTimeString("ru-RU",{hour:"2-digit",minute:"2-digit"}),
    }]);
    setMsgText("");
  }

  return (
    <div style={{height:"calc(100vh - 64px)",display:"flex",flexDirection:"column",fontFamily:FB}}>
      {/* mode toggle */}
      <div style={{padding:"10px 20px",borderBottom:`1px solid ${C.border}`,display:"flex",justifyContent:"space-between",alignItems:"center",background:C.s1,flexShrink:0}}>
        <span style={{fontFamily:FH,fontWeight:800,fontSize:16,color:C.text}}>Чат</span>
        <div style={{display:"flex",borderRadius:10,overflow:"hidden",border:`1px solid ${C.border}`}}>
          <button onClick={()=>setMode("user")} style={{padding:"7px 16px",fontSize:13,fontWeight:700,fontFamily:FH,background:mode==="user"?C.teal:"transparent",color:mode==="user"?C.bg:C.muted,transition:"all .15s"}}>
            Родитель
          </button>
          <button onClick={()=>setMode("institution")} style={{padding:"7px 16px",fontSize:13,fontWeight:700,fontFamily:FH,background:mode==="institution"?C.teal:"transparent",color:mode==="institution"?C.bg:C.muted,transition:"all .15s"}}>
            Учреждение
          </button>
        </div>
      </div>

      <div style={{flex:1,display:"grid",gridTemplateColumns:"300px 1fr",overflow:"hidden"}}>
        {/* ── SIDEBAR ── */}
        <aside style={{borderRight:`1px solid ${C.border}`,display:"flex",flexDirection:"column",overflow:"hidden"}}>
          <div style={{padding:"14px 14px 10px",flexShrink:0}}>
            <div style={{display:"flex",alignItems:"center",gap:8,background:C.s2,borderRadius:10,padding:"9px 12px"}}>
              <Search size={14} style={{color:C.muted}}/>
              <input placeholder="Поиск диалогов…" style={{background:"transparent",border:"none",outline:"none",flex:1,fontSize:13.5,color:C.text,fontFamily:FB}}/>
            </div>
          </div>
          <div style={{flex:1,overflowY:"auto"}}>
            {CONVS.map(conv=>{
              const lastMsg = messages.filter(m=>m.convId===conv.id).at(-1);
              const active = conv.id===activeConv;
              return (
                <button key={conv.id} onClick={()=>setActiveConv(conv.id)}
                  style={{width:"100%",display:"flex",alignItems:"center",gap:12,padding:"14px 16px",background:active?`${C.teal}15`:"transparent",borderLeft:`3px solid ${active?C.teal:"transparent"}`,transition:"all .14s",textAlign:"left"}}>
                  <div style={{width:44,height:44,borderRadius:12,background:conv.color,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:900,fontSize:17,color:"#fff",flexShrink:0}}>
                    {conv.name[0]}
                  </div>
                  <div style={{flex:1,minWidth:0}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"baseline"}}>
                      <p style={{fontFamily:FH,fontWeight:700,fontSize:14,color:C.text,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",maxWidth:130}}>{conv.name}</p>
                      <span style={{fontSize:11,color:C.muted,flexShrink:0}}>{lastMsg?.time ?? ""}</span>
                    </div>
                    <p style={{fontSize:12.5,color:C.muted,whiteSpace:"nowrap",overflow:"hidden",textOverflow:"ellipsis",marginTop:2}}>{lastMsg?.text ?? ""}</p>
                  </div>
                  {conv.unread>0 && <span style={{width:18,height:18,borderRadius:"50%",background:C.teal,color:C.bg,fontSize:10.5,fontWeight:800,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{conv.unread}</span>}
                </button>
              );
            })}
          </div>
        </aside>

        {/* ── CHAT AREA ── */}
        {conv ? (
          <div style={{display:"flex",flexDirection:"column",overflow:"hidden"}}>
            {/* header */}
            <div style={{padding:"14px 20px",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:12,flexShrink:0,background:C.s1}}>
              <div style={{width:38,height:38,borderRadius:10,background:conv.color,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:900,fontSize:16,color:"#fff"}}>{conv.name[0]}</div>
              <div>
                <p style={{fontFamily:FH,fontWeight:700,fontSize:15,color:C.text}}>{conv.name}</p>
                <p style={{fontSize:12.5,color:C.ok}}>● онлайн</p>
              </div>
              <div style={{marginLeft:"auto",display:"flex",gap:10}}>
                {[Phone,Video,MoreHorizontal].map((Icon,i)=>(
                  <button key={i} style={{width:34,height:34,borderRadius:8,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center",background:"transparent"}}>
                    <Icon size={15} style={{color:C.muted}}/>
                  </button>
                ))}
              </div>
            </div>

            {/* messages */}
            <div style={{flex:1,overflowY:"auto",padding:"20px 24px",display:"flex",flexDirection:"column",gap:12}}>
              {convMessages.map(msg=>{
                const isMe = msg.from==="me";
                return (
                  <div key={msg.id} style={{display:"flex",justifyContent:isMe?"flex-end":"flex-start"}}>
                    {!isMe && <div style={{width:32,height:32,borderRadius:8,background:conv.color,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:900,fontSize:13,color:"#fff",flexShrink:0,marginRight:8,alignSelf:"flex-end"}}>{conv.name[0]}</div>}
                    <div style={{maxWidth:"65%"}}>
                      <div style={{padding:"10px 14px",borderRadius:isMe?"14px 14px 4px 14px":"14px 14px 14px 4px",background:isMe?C.teal:C.s2,color:isMe?C.bg:C.text,fontSize:14,lineHeight:1.65,fontFamily:FB}}>
                        {msg.text}
                      </div>
                      <p style={{fontSize:11,color:C.muted,marginTop:4,textAlign:isMe?"right":"left"}}>{msg.time}</p>
                    </div>
                  </div>
                );
              })}
              {convMessages.length===0 && (
                <div style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",color:C.muted,gap:10}}>
                  <div style={{width:56,height:56,borderRadius:16,background:conv.color,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:900,fontSize:24,color:"#fff",marginBottom:4}}>{conv.name[0]}</div>
                  <p style={{fontFamily:FH,fontWeight:700,fontSize:16,color:C.text}}>{conv.name}</p>
                  <p style={{fontSize:13.5}}>Начните диалог</p>
                </div>
              )}
            </div>

            {/* input */}
            <div style={{padding:"14px 20px",borderTop:`1px solid ${C.border}`,display:"flex",gap:10,alignItems:"center",flexShrink:0}}>
              <button style={{width:34,height:34,borderRadius:8,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center"}}>
                <Paperclip size={15} style={{color:C.muted}}/>
              </button>
              <div style={{flex:1,display:"flex",alignItems:"center",gap:8,background:C.s2,borderRadius:12,padding:"10px 14px",border:`1px solid ${C.border}`}}>
                <input value={msgText} onChange={e=>setMsgText(e.target.value)} onKeyDown={e=>e.key==="Enter"&&send()}
                  placeholder="Написать сообщение…"
                  style={{flex:1,background:"transparent",border:"none",outline:"none",fontSize:14,color:C.text,fontFamily:FB}}/>
                <Smile size={16} style={{color:C.muted,flexShrink:0}}/>
              </div>
              <button onClick={send} style={{width:40,height:40,borderRadius:11,background:msgText.trim()?C.teal:C.s3,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0,transition:"background .15s"}}>
                <Send size={16} style={{color:msgText.trim()?C.bg:C.muted}}/>
              </button>
            </div>
          </div>
        ) : (
          <div style={{display:"flex",alignItems:"center",justifyContent:"center",color:C.muted,fontSize:14}}>
            Выберите диалог
          </div>
        )}
      </div>
    </div>
  );
}
