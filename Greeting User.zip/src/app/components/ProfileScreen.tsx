import { useState } from "react";
import { ArrowLeft, MapPin, Phone, Globe, Star, CheckCircle, Award, Users, Utensils, Camera, MessageSquare, Newspaper, BookOpen, ChevronRight, GraduationCap } from "lucide-react";
import { C, FH, FB, INSTITUTIONS, ALL_STAFF, REVIEWS, NEWS_ITEMS } from "../data";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";
type Tab = "about"|"staff"|"gallery"|"achievements"|"menu"|"reviews"|"news"|"contacts";

const ACH_ICONS: Record<string,string> = { gold:"🥇", silver:"🥈", bronze:"🥉", special:"🏆" };
const ACH_CATEGORIES = [
  {key:"institution" as const, label:"Достижения учреждения"},
  {key:"student"     as const, label:"Достижения учеников"},
  {key:"teacher"     as const, label:"Достижения педагогов"},
];

function Stars({ s, size=13 }:{s:number;size?:number}) {
  return (
    <span style={{display:"flex",gap:2}}>
      {[1,2,3,4,5].map(i=>(<svg key={i} width={size} height={size} viewBox="0 0 24 24" fill={i<=Math.round(s)?C.gold:C.dim}><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>))}
    </span>
  );
}

function MetricBar({ label, value }:{label:string;value:number}) {
  const pct = (value/5)*100;
  const color = pct>=90?C.ok:pct>=75?C.teal:pct>=60?C.gold:C.red;
  return (
    <div style={{marginBottom:10}}>
      <div style={{display:"flex",justifyContent:"space-between",fontSize:12.5,color:C.sub,marginBottom:5,fontFamily:FH}}>
        <span>{label}</span><span style={{color,fontWeight:700}}>{value.toFixed(1)}</span>
      </div>
      <div style={{height:5,borderRadius:999,background:C.s3}}>
        <div style={{height:"100%",borderRadius:999,background:color,width:`${pct}%`,transition:"width .5s"}}/>
      </div>
    </div>
  );
}

export function ProfileScreen({ instId, set, setPersonId }: { instId:number; set:(s:Screen)=>void; setPersonId:(id:string)=>void }) {
  const [tab, setTab] = useState<Tab>("about");
  const [lightbox, setLightbox] = useState<string|null>(null);
  const [showFullBio, setShowFullBio] = useState(false);

  const inst = INSTITUTIONS.find(i=>i.id===instId) ?? INSTITUTIONS[0];
  const staff = ALL_STAFF.filter(p=>p.instId===inst.id);
  const reviews = REVIEWS.filter(r=>r.instId===inst.id);
  const news = NEWS_ITEMS.filter(n => n.status === "published");

  const TABS: {k:Tab; label:string; icon:any}[] = [
    {k:"about",       label:"О нас",       icon:BookOpen},
    {k:"staff",       label:"Персонал",    icon:Users},
    {k:"gallery",     label:"Галерея",     icon:Camera},
    {k:"achievements",label:"Достижения",  icon:Award},
    {k:"menu",        label:"Питание",     icon:Utensils},
    {k:"reviews",     label:"Отзывы",      icon:Star},
    {k:"news",        label:"Новости",     icon:Newspaper},
    {k:"contacts",    label:"Контакты",    icon:MapPin},
  ];

  return (
    <div style={{fontFamily:FB}}>
      {/* ── COVER ── */}
      <div style={{position:"relative",height:340,overflow:"hidden"}}>
        <img src={inst.coverPhoto} alt={inst.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
        <div style={{position:"absolute",inset:0,background:"linear-gradient(180deg,rgba(7,24,26,.15) 0%,rgba(7,24,26,.85) 75%,#07181A 100%)"}}/>
        <div style={{position:"absolute",top:20,left:28}}>
          <button onClick={()=>set("search")} style={{display:"inline-flex",alignItems:"center",gap:7,padding:"8px 14px",borderRadius:9,background:"rgba(0,0,0,.5)",border:`1px solid rgba(255,255,255,.15)`,color:"#fff",fontFamily:FH,fontWeight:700,fontSize:13,backdropFilter:"blur(8px)"}}>
            <ArrowLeft size={14}/> Назад
          </button>
        </div>
        <div style={{position:"absolute",bottom:24,left:28,right:28,display:"flex",alignItems:"flex-end",justifyContent:"space-between"}}>
          <div>
            <div style={{display:"flex",gap:8,marginBottom:10,flexWrap:"wrap"}}>
              <span style={{fontSize:12,fontWeight:700,padding:"4px 10px",borderRadius:7,background:inst.color,color:C.bg,fontFamily:FH}}>{inst.type}</span>
              {inst.ver && <span style={{fontSize:12,fontWeight:700,padding:"4px 10px",borderRadius:7,background:`${C.ok}22`,border:`1px solid ${C.ok}`,color:C.ok,fontFamily:FH,display:"flex",alignItems:"center",gap:4}}><CheckCircle size={11}/> МОН РТ</span>}
              {inst.tag && <span style={{fontSize:12,fontWeight:700,padding:"4px 10px",borderRadius:7,background:`${C.gold}22`,border:`1px solid ${C.gold}`,color:C.gold,fontFamily:FH}}>{inst.tag}</span>}
            </div>
            <h1 style={{fontFamily:FH,fontWeight:900,fontSize:"clamp(22px,3vw,36px)",color:"#fff",lineHeight:1.1,marginBottom:6}}>{inst.name}</h1>
            <div style={{display:"flex",alignItems:"center",gap:12,flexWrap:"wrap"}}>
              <div style={{display:"flex",alignItems:"center",gap:6}}>
                <Stars s={inst.score} size={15}/>
                <span style={{fontFamily:FH,fontWeight:800,fontSize:15,color:"#fff"}}>{inst.score}</span>
                <span style={{fontSize:13,color:"rgba(255,255,255,.55)"}}>({inst.rev} отзыва)</span>
              </div>
              <span style={{fontSize:13,color:"rgba(255,255,255,.6)",display:"flex",alignItems:"center",gap:4}}><MapPin size={12}/>{inst.area}, Душанбе</span>
            </div>
          </div>
          <div style={{textAlign:"right"}}>
            <p style={{fontFamily:FH,fontWeight:900,fontSize:30,color:"#fff"}}>{inst.price} <span style={{fontSize:14,fontWeight:400,color:"rgba(255,255,255,.55)"}}>сом/мес</span></p>
          </div>
        </div>
      </div>

      {/* ── TABS ── */}
      <div style={{borderBottom:`1px solid ${C.border}`,background:C.bg,position:"sticky",top:64,zIndex:20}}>
        <div style={{maxWidth:1260,margin:"0 auto",padding:"0 28px",display:"flex",gap:2,overflowX:"auto"}}>
          {TABS.map(({k,label,icon:Icon})=>(
            <button key={k} onClick={()=>setTab(k)}
              style={{display:"flex",alignItems:"center",gap:6,padding:"14px 14px",fontFamily:FH,fontWeight:700,fontSize:13,color:tab===k?C.teal:C.muted,borderBottom:`2px solid ${tab===k?C.teal:"transparent"}`,whiteSpace:"nowrap",transition:"all .14s"}}>
              <Icon size={14}/> {label}
            </button>
          ))}
        </div>
      </div>

      {/* ── CONTENT ── */}
      <div style={{maxWidth:1260,margin:"0 auto",padding:"32px 28px 80px"}}>

        {/* ABOUT */}
        {tab==="about" && (
          <div style={{display:"grid",gridTemplateColumns:"1fr 320px",gap:24,alignItems:"start"}}>
            <div style={{display:"flex",flexDirection:"column",gap:20}}>
              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:26}}>
                <h2 style={{fontFamily:FH,fontWeight:800,fontSize:19,color:C.text,marginBottom:14}}>О нас</h2>
                <p style={{fontSize:14.5,color:C.sub,lineHeight:1.78,maxHeight:showFullBio?undefined:120,overflow:showFullBio?undefined:"hidden"}}>
                  {inst.description}
                </p>
                {inst.description.length > 200 && (
                  <button onClick={()=>setShowFullBio(!showFullBio)} style={{marginTop:10,fontSize:13,color:C.teal,fontFamily:FH,fontWeight:600}}>
                    {showFullBio?"Свернуть":"Читать полностью..."}
                  </button>
                )}
              </div>

              {/* key facts */}
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
                {[
                  {l:"Основана",v:inst.founded},
                  {l:"Учеников",v:inst.students},
                  {l:"Возраст",v:inst.age},
                ].map(({l,v})=>(
                  <div key={l} style={{borderRadius:14,border:`1px solid ${C.border}`,background:C.s1,padding:"16px",textAlign:"center"}}>
                    <p style={{fontFamily:FH,fontWeight:900,fontSize:22,color:C.teal,marginBottom:4}}>{v}</p>
                    <p style={{fontSize:12.5,color:C.sub}}>{l}</p>
                  </div>
                ))}
              </div>

              {/* metrics */}
              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:26}}>
                <h3 style={{fontFamily:FH,fontWeight:800,fontSize:17,color:C.text,marginBottom:16}}>Рейтинг по параметрам</h3>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"0 28px"}}>
                  {inst.metrics.map(m=>(
                    <MetricBar key={m.label} label={m.label} value={m.v}/>
                  ))}
                </div>
              </div>

              {/* features */}
              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:26}}>
                <h3 style={{fontFamily:FH,fontWeight:800,fontSize:17,color:C.text,marginBottom:16}}>Услуги и возможности</h3>
                <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
                  {[
                    {l:"Транспорт",v:inst.transport,icon:"🚌"},
                    {l:"Питание",v:inst.food,icon:"🍽"},
                    {l:"Халяль",v:inst.halal,icon:"☪"},
                    {l:"Психолог",v:true,icon:"🧠"},
                    {l:"Спортзал",v:true,icon:"⚽"},
                    {l:"Библиотека",v:true,icon:"📚"},
                    {l:"Мед. кабинет",v:true,icon:"🏥"},
                    {l:"Видеонаблюдение",v:true,icon:"📹"},
                    {l:"Wi-Fi",v:true,icon:"📡"},
                  ].map(f=>(
                    <div key={f.l} style={{display:"flex",alignItems:"center",gap:8,padding:"10px 12px",borderRadius:10,background:f.v?`${C.ok}12`:C.s2,border:`1px solid ${f.v?C.ok+"33":C.border}`}}>
                      <span style={{fontSize:17}}>{f.icon}</span>
                      <span style={{fontSize:12.5,fontFamily:FH,fontWeight:600,color:f.v?C.text:C.dim}}>{f.l}</span>
                      {f.v && <CheckCircle size={11} style={{color:C.ok,marginLeft:"auto"}}/>}
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* sidebar */}
            <div style={{display:"flex",flexDirection:"column",gap:16}}>
              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:22}}>
                <h3 style={{fontFamily:FH,fontWeight:800,fontSize:16,color:C.text,marginBottom:14}}>Контакты</h3>
                {[
                  {icon:<Phone size={15}/>,l:inst.phone},
                  {icon:<Globe size={15}/>,l:inst.website},
                  {icon:<MapPin size={15}/>,l:inst.address},
                ].map((c,i)=>(
                  <div key={i} style={{display:"flex",alignItems:"flex-start",gap:10,fontSize:13.5,color:C.sub,padding:"8px 0",borderBottom:i<2?`1px solid ${C.border}`:"none"}}>
                    <span style={{color:C.teal,flexShrink:0,marginTop:1}}>{c.icon}</span>{c.l}
                  </div>
                ))}
                <button style={{marginTop:14,width:"100%",padding:"11px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14,display:"flex",alignItems:"center",justifyContent:"center",gap:7}}>
                  <MessageSquare size={15}/> Написать
                </button>
              </div>

              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:22}}>
                <h3 style={{fontFamily:FH,fontWeight:800,fontSize:16,color:C.text,marginBottom:14}}>Режим работы</h3>
                {[["Пн–Пт","07:30 – 18:00"],["Суббота","08:00 – 14:00"],["Воскресенье","Выходной"]].map(([d,t])=>(
                  <div key={d} style={{display:"flex",justifyContent:"space-between",fontSize:13.5,padding:"7px 0",borderBottom:`1px solid ${C.border}`,color:C.sub}}>
                    <span>{d}</span><span style={{color:t==="Выходной"?C.red:C.text,fontWeight:600}}>{t}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* STAFF */}
        {tab==="staff" && (
          <div>
            <h2 style={{fontFamily:FH,fontWeight:800,fontSize:22,color:C.text,marginBottom:24}}>Педагогический состав</h2>
            {staff.length === 0 ? (
              <p style={{color:C.muted,fontSize:14}}>Персонал не добавлен</p>
            ) : (
              <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:18}}>
                {staff.map(p=>(
                  <button key={p.id} onClick={()=>{setPersonId(p.id);set("person")}}
                    style={{textAlign:"left",borderRadius:18,overflow:"hidden",border:`1px solid ${C.border}`,background:C.s1,cursor:"pointer",transition:"all .2s"}}>
                    <div style={{height:220,overflow:"hidden",position:"relative"}}>
                      <img src={p.photo} alt={p.name} style={{width:"100%",height:"100%",objectFit:"cover",transition:"transform .3s"}}/>
                      <div style={{position:"absolute",inset:0,background:"linear-gradient(180deg,transparent 55%,rgba(7,24,26,.9) 100%)"}}/>
                      <div style={{position:"absolute",bottom:14,left:14,right:14}}>
                        <p style={{fontFamily:FH,fontWeight:800,fontSize:16,color:C.text}}>{p.name}</p>
                        <p style={{fontSize:12.5,color:C.teal,fontFamily:FH}}>{p.roleLabel}</p>
                      </div>
                    </div>
                    <div style={{padding:"14px 16px"}}>
                      {p.subject && (
                        <div style={{display:"flex",gap:6,marginBottom:10}}>
                          <span style={{fontSize:11,fontWeight:600,padding:"3px 8px",borderRadius:6,background:`${C.teal}18`,color:C.teal,fontFamily:FH}}>{p.subject}</span>
                        </div>
                      )}
                      <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                        <span style={{fontSize:13,color:C.sub}}>{p.exp} опыта</span>
                        <span style={{display:"flex",alignItems:"center",gap:4,fontSize:12.5,color:C.teal,fontFamily:FH,fontWeight:600}}>Подробнее <ChevronRight size={13}/></span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {/* GALLERY */}
        {tab==="gallery" && (
          <div>
            <h2 style={{fontFamily:FH,fontWeight:800,fontSize:22,color:C.text,marginBottom:24}}>Фотогалерея</h2>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:10}}>
              {inst.gallery.map((g,i)=>(
                <div key={i} onClick={()=>setLightbox(g.url)} style={{aspectRatio:"4/3",borderRadius:12,overflow:"hidden",cursor:"pointer",position:"relative"}}>
                  <img src={g.url} alt={g.label} style={{width:"100%",height:"100%",objectFit:"cover",transition:"transform .3s"}}
                    onMouseEnter={e=>(e.currentTarget.style.transform="scale(1.05)")}
                    onMouseLeave={e=>(e.currentTarget.style.transform="scale(1)")}/>
                  <div style={{position:"absolute",bottom:0,left:0,right:0,padding:"6px 10px",background:"linear-gradient(transparent,rgba(0,0,0,.6))",fontSize:12.5,color:"rgba(255,255,255,.8)",fontFamily:FH}}>{g.label}</div>
                </div>
              ))}
            </div>
            {lightbox && (
              <div onClick={()=>setLightbox(null)} style={{position:"fixed",inset:0,background:"rgba(0,0,0,.9)",zIndex:999,display:"flex",alignItems:"center",justifyContent:"center",cursor:"pointer"}}>
                <img src={lightbox} alt="" style={{maxWidth:"92vw",maxHeight:"92vh",objectFit:"contain",borderRadius:12}}/>
              </div>
            )}
          </div>
        )}

        {/* ACHIEVEMENTS */}
        {tab==="achievements" && (
          <div>
            <h2 style={{fontFamily:FH,fontWeight:800,fontSize:22,color:C.text,marginBottom:24}}>Достижения</h2>
            {ACH_CATEGORIES.map(cat=>{
              const items = inst.achievements.filter(a=>a.type===cat.key);
              if(!items.length) return null;
              return (
                <div key={cat.key} style={{marginBottom:32}}>
                  <h3 style={{fontFamily:FH,fontWeight:700,fontSize:17,color:C.teal,marginBottom:14}}>{cat.label}</h3>
                  <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:12}}>
                    {items.map(ach=>(
                      <div key={ach.id} style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,padding:"18px 20px"}}>
                        <span style={{fontSize:28,display:"block",marginBottom:10}}>{ACH_ICONS[ach.category]}</span>
                        <p style={{fontFamily:FH,fontWeight:700,fontSize:15,color:C.text,marginBottom:4}}>{ach.title}</p>
                        <p style={{fontSize:12.5,color:C.sub}}>{ach.year}</p>
                        <p style={{fontSize:12.5,color:C.muted,marginTop:4}}>{ach.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
            {!inst.achievements.length && <p style={{color:C.muted,fontSize:14}}>Достижения не добавлены</p>}
          </div>
        )}

        {/* MENU */}
        {tab==="menu" && (
          <div>
            <h2 style={{fontFamily:FH,fontWeight:800,fontSize:22,color:C.text,marginBottom:6}}>Меню питания</h2>
            <p style={{fontSize:14,color:C.sub,marginBottom:24}}>Еженедельное расписание питания</p>
            {!inst.food ? (
              <div style={{padding:48,borderRadius:16,border:`1px dashed ${C.border}`,textAlign:"center",color:C.muted}}>
                <Utensils size={28} style={{margin:"0 auto 12px",color:C.dim}}/>
                <p style={{fontFamily:FH,fontWeight:700,fontSize:16,color:C.text,marginBottom:6}}>Питание не предусмотрено</p>
                <p style={{fontSize:13.5}}>В данном учреждении нет организованного питания</p>
              </div>
            ) : inst.foodMenu ? (
              <div style={{display:"grid",gridTemplateColumns:`repeat(${inst.foodMenu.length},1fr)`,gap:14}}>
                {inst.foodMenu.map(dayMenu=>(
                  <div key={dayMenu.day} style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,overflow:"hidden"}}>
                    <div style={{padding:"10px 14px",background:C.s2,borderBottom:`1px solid ${C.border}`}}>
                      <p style={{fontFamily:FH,fontWeight:800,fontSize:13,color:C.teal}}>{dayMenu.day}</p>
                    </div>
                    <div style={{padding:"12px 14px",display:"flex",flexDirection:"column",gap:10}}>
                      {dayMenu.meals.map((meal,mi)=>(
                        <div key={mi}>
                          <p style={{fontSize:12.5,color:C.sub,marginBottom:4}}>{meal.name}</p>
                          <p style={{fontSize:11.5,color:C.muted}}>{meal.cal}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:14}}>
                {["Понедельник","Вторник","Среда","Четверг","Пятница"].map(day=>(
                  <div key={day} style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,overflow:"hidden"}}>
                    <div style={{padding:"10px 14px",background:C.s2,borderBottom:`1px solid ${C.border}`}}>
                      <p style={{fontFamily:FH,fontWeight:800,fontSize:13,color:C.teal}}>{day}</p>
                    </div>
                    <div style={{padding:"12px 14px",display:"flex",flexDirection:"column",gap:8}}>
                      {[{meal:"Завтрак",txt:"Каша + чай"},{meal:"Обед",txt:"Суп + плов"},{meal:"Полдник",txt:"Фрукты"}].map(({meal,txt})=>(
                        <div key={meal}>
                          <p style={{fontSize:11,fontWeight:700,textTransform:"uppercase",color:C.dim,fontFamily:FH,marginBottom:3}}>{meal}</p>
                          <p style={{fontSize:12.5,color:C.sub}}>{txt}</p>
                        </div>
                      ))}
                      <p style={{fontSize:11.5,color:C.muted,marginTop:4,borderTop:`1px solid ${C.border}`,paddingTop:6}}>~650 ккал</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* REVIEWS */}
        {tab==="reviews" && (
          <div>
            <div style={{display:"grid",gridTemplateColumns:"240px 1fr",gap:24,marginBottom:32}}>
              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:24,textAlign:"center"}}>
                <p style={{fontFamily:FH,fontWeight:900,fontSize:52,color:C.text,lineHeight:1}}>{inst.score}</p>
                <Stars s={inst.score} size={18}/>
                <p style={{fontSize:13,color:C.sub,marginTop:8}}>{inst.rev} отзывов</p>
                <div style={{marginTop:16}}>
                  {[5,4,3,2,1].map(n=>(
                    <div key={n} style={{display:"flex",alignItems:"center",gap:8,marginBottom:4}}>
                      <span style={{fontSize:12.5,color:C.sub,width:12}}>{n}</span>
                      <div style={{flex:1,height:6,borderRadius:999,background:C.s3}}>
                        <div style={{height:"100%",borderRadius:999,background:C.gold,width:`${n===5?65:n===4?25:n===3?7:3}%`}}/>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div style={{display:"flex",flexDirection:"column",gap:14}}>
                {reviews.map(r=>(
                  <div key={r.id} style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,padding:"18px 20px"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                      <div style={{display:"flex",gap:10}}>
                        <div style={{width:38,height:38,borderRadius:"50%",background:C.teal,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:800,color:C.bg,fontSize:15}}>{r.init}</div>
                        <div>
                          <p style={{fontFamily:FH,fontWeight:700,fontSize:14,color:C.text}}>{r.name}</p>
                          <p style={{fontSize:12.5,color:C.sub}}>{r.date}</p>
                        </div>
                      </div>
                      <Stars s={r.score}/>
                    </div>
                    <p style={{fontSize:14,color:C.sub,lineHeight:1.7}}>{r.text}</p>
                    {r.reply && (
                      <div style={{marginTop:10,padding:"10px 14px",borderRadius:10,background:`${C.teal}12`,borderLeft:`3px solid ${C.teal}`}}>
                        <p style={{fontSize:12,fontWeight:700,color:C.teal,fontFamily:FH,marginBottom:4}}>Ответ учреждения:</p>
                        <p style={{fontSize:13.5,color:C.sub}}>{r.reply}</p>
                      </div>
                    )}
                  </div>
                ))}
                {reviews.length===0 && <p style={{color:C.muted,fontSize:14}}>Отзывов пока нет</p>}
              </div>
            </div>
          </div>
        )}

        {/* NEWS */}
        {tab==="news" && (
          <div>
            <h2 style={{fontFamily:FH,fontWeight:800,fontSize:22,color:C.text,marginBottom:24}}>Новости</h2>
            <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:18}}>
              {news.map(n=>(
                <div key={n.id} style={{borderRadius:18,overflow:"hidden",border:`1px solid ${C.border}`,background:C.s1}}>
                  {n.coverUrl && <div style={{height:160,overflow:"hidden"}}><img src={n.coverUrl} alt={n.title} style={{width:"100%",height:"100%",objectFit:"cover"}}/></div>}
                  <div style={{padding:"16px 18px"}}>
                    <span style={{fontSize:11.5,fontWeight:700,color:C.teal,fontFamily:FH,textTransform:"uppercase",letterSpacing:".05em"}}>{n.category}</span>
                    <h3 style={{fontFamily:FH,fontWeight:800,fontSize:15.5,color:C.text,margin:"6px 0 8px",lineHeight:1.3}}>{n.title}</h3>
                    <p style={{fontSize:13,color:C.sub,lineHeight:1.6,marginBottom:10}}>{n.content.slice(0,100)}...</p>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <p style={{fontSize:12,color:C.muted}}>{n.date}</p>
                      <p style={{fontSize:12,color:C.muted}}>{n.views} просм.</p>
                    </div>
                  </div>
                </div>
              ))}
              {!news.length && <p style={{color:C.muted,fontSize:14,gridColumn:"1/-1"}}>Новостей пока нет</p>}
            </div>
          </div>
        )}

        {/* CONTACTS */}
        {tab==="contacts" && (
          <div style={{display:"grid",gridTemplateColumns:"1fr 380px",gap:24}}>
            <div style={{display:"flex",flexDirection:"column",gap:16}}>
              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:26}}>
                <h2 style={{fontFamily:FH,fontWeight:800,fontSize:19,color:C.text,marginBottom:18}}>Контактная информация</h2>
                {[
                  {icon:<Phone size={16}/>,label:"Телефон",val:inst.phone},
                  {icon:<Globe size={16}/>,label:"Веб-сайт",val:inst.website},
                  {icon:<MapPin size={16}/>,label:"Адрес",val:inst.address},
                  {icon:<GraduationCap size={16}/>,label:"Эл. почта",val:inst.email},
                ].map((c,i)=>(
                  <div key={i} style={{display:"flex",alignItems:"flex-start",gap:14,padding:"14px 0",borderBottom:i<3?`1px solid ${C.border}`:"none"}}>
                    <span style={{color:C.teal,width:32,height:32,borderRadius:8,background:`${C.teal}18`,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>{c.icon}</span>
                    <div>
                      <p style={{fontSize:12,fontWeight:700,color:C.dim,textTransform:"uppercase",fontFamily:FH,letterSpacing:".05em",marginBottom:3}}>{c.label}</p>
                      <p style={{fontSize:14.5,color:C.text}}>{c.val}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:26}}>
              <h3 style={{fontFamily:FH,fontWeight:800,fontSize:18,color:C.text,marginBottom:18}}>Записаться на визит</h3>
              {["Ваше имя","Телефон","Дата"].map(pl=>(
                <input key={pl} placeholder={pl} style={{display:"block",width:"100%",padding:"11px 14px",borderRadius:10,border:`1px solid ${C.border}`,background:C.s2,color:C.text,fontFamily:FB,fontSize:14,outline:"none",marginBottom:10,boxSizing:"border-box"}}/>
              ))}
              <textarea placeholder="Комментарий" style={{display:"block",width:"100%",padding:"11px 14px",borderRadius:10,border:`1px solid ${C.border}`,background:C.s2,color:C.text,fontFamily:FB,fontSize:14,outline:"none",resize:"none",height:90,marginBottom:14,boxSizing:"border-box"}}/>
              <button style={{width:"100%",padding:13,borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14.5}}>Отправить заявку</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
