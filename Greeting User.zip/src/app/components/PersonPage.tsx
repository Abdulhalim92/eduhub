import { ArrowLeft, Mail, Phone, Award, GraduationCap, BookOpen, ChevronRight } from "lucide-react";
import { C, FH, FB, ALL_STAFF } from "../data";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";

const ACHIEVEMENT_ICONS: Record<string,string> = { gold:"🥇", silver:"🥈", bronze:"🥉", special:"🏆" };

export function PersonPage({ personId, set }: { personId:string; set:(s:Screen)=>void }) {
  const person = ALL_STAFF.find(p=>p.id===personId);
  if(!person) return <div style={{padding:40,color:C.muted,textAlign:"center"}}>Сотрудник не найден</div>;

  return (
    <div style={{maxWidth:900,margin:"0 auto",padding:"28px 28px 80px",fontFamily:FB}}>
      <button onClick={()=>set("profile")} style={{display:"inline-flex",alignItems:"center",gap:7,fontFamily:FH,fontWeight:700,fontSize:13.5,color:C.teal,marginBottom:24,padding:"8px 14px",borderRadius:9,border:`1px solid ${C.teal}40`,background:`${C.teal}10`}}>
        <ArrowLeft size={15}/> Назад к профилю
      </button>

      <div style={{display:"grid",gridTemplateColumns:"300px 1fr",gap:24,alignItems:"start"}}>
        {/* ── LEFT CARD ── */}
        <div style={{borderRadius:20,overflow:"hidden",border:`1px solid ${C.border}`,background:C.s1}}>
          <div style={{height:280,overflow:"hidden",position:"relative"}}>
            <img src={person.photo} alt={person.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
            <div style={{position:"absolute",inset:0,background:"linear-gradient(180deg,transparent 50%,rgba(7,24,26,.95) 100%)"}}/>
            <div style={{position:"absolute",bottom:16,left:16,right:16}}>
              <p style={{fontFamily:FH,fontWeight:900,fontSize:20,color:C.text,lineHeight:1.2}}>{person.name}</p>
              <p style={{fontSize:13.5,color:C.teal,fontFamily:FH,marginTop:3}}>{person.roleLabel}</p>
            </div>
          </div>

          <div style={{padding:18}}>
            {person.subject && (
              <div style={{display:"flex",gap:8,flexWrap:"wrap",marginBottom:16}}>
                <span style={{fontSize:12,fontWeight:600,padding:"4px 10px",borderRadius:7,background:`${C.teal}18`,color:C.teal,fontFamily:FH}}>{person.subject}</span>
              </div>
            )}

            <div style={{display:"flex",flexDirection:"column",gap:8}}>
              <div style={{display:"flex",alignItems:"center",gap:8,fontSize:13.5,color:C.sub}}>
                <GraduationCap size={15} style={{color:C.teal,flexShrink:0}}/>
                Опыт: <b style={{color:C.text}}>{person.exp}</b>
              </div>
              {person.email && (
                <div style={{display:"flex",alignItems:"center",gap:8,fontSize:13,color:C.sub}}>
                  <Mail size={14} style={{color:C.teal,flexShrink:0}}/>{person.email}
                </div>
              )}
              {person.phone && (
                <div style={{display:"flex",alignItems:"center",gap:8,fontSize:13,color:C.sub}}>
                  <Phone size={14} style={{color:C.teal,flexShrink:0}}/>{person.phone}
                </div>
              )}
              {person.rating && (
                <div style={{display:"flex",alignItems:"center",gap:8,fontSize:13.5,color:C.sub}}>
                  <span style={{color:C.gold}}>★</span>
                  <b style={{color:C.text}}>{person.rating}</b>
                  <span style={{color:C.muted}}>({person.reviews} отзывов)</span>
                </div>
              )}
            </div>

            <button style={{marginTop:16,width:"100%",padding:"10px",borderRadius:10,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:700,fontSize:13.5,display:"flex",alignItems:"center",justifyContent:"center",gap:7}}>
              <Mail size={14}/> Написать
            </button>
          </div>
        </div>

        {/* ── RIGHT ── */}
        <div style={{display:"flex",flexDirection:"column",gap:20}}>
          {/* Bio */}
          <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:24}}>
            <h2 style={{fontFamily:FH,fontWeight:800,fontSize:18,color:C.text,marginBottom:12}}>О себе</h2>
            <p style={{fontSize:14.5,color:C.sub,lineHeight:1.75}}>{person.bio}</p>
          </div>

          {/* Education */}
          {person.education.length > 0 && (
            <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:24}}>
              <h2 style={{fontFamily:FH,fontWeight:800,fontSize:18,color:C.text,marginBottom:16,display:"flex",alignItems:"center",gap:8}}>
                <GraduationCap size={18} style={{color:C.teal}}/> Образование
              </h2>
              <div style={{display:"flex",flexDirection:"column",gap:12}}>
                {person.education.map((ed,i)=>(
                  <div key={i} style={{display:"flex",gap:14,alignItems:"flex-start"}}>
                    <div style={{width:8,height:8,borderRadius:"50%",background:C.teal,marginTop:6,flexShrink:0}}/>
                    <p style={{fontSize:14,color:C.sub,lineHeight:1.6}}>{ed}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Achievements */}
          {person.achievements.length > 0 && (
            <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:24}}>
              <h2 style={{fontFamily:FH,fontWeight:800,fontSize:18,color:C.text,marginBottom:16,display:"flex",alignItems:"center",gap:8}}>
                <Award size={18} style={{color:C.gold}}/> Достижения
              </h2>
              <div style={{display:"flex",flexDirection:"column",gap:10}}>
                {person.achievements.map(ach=>(
                  <div key={ach.id} style={{display:"flex",gap:12,alignItems:"flex-start",padding:"12px 14px",borderRadius:12,background:C.s2}}>
                    <span style={{fontSize:22}}>{ACHIEVEMENT_ICONS[ach.category] ?? "🏆"}</span>
                    <div>
                      <p style={{fontFamily:FH,fontWeight:700,fontSize:14,color:C.text}}>{ach.title}</p>
                      <p style={{fontSize:12.5,color:C.sub}}>{ach.year} · {ach.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
