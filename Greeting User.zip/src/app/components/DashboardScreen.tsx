import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { Plus, Edit2, Trash2, Eye, Image, Video, X, Check, Bell, Lock, Globe, Users, MessageSquare, Star, TrendingUp, Newspaper, Settings } from "lucide-react";
import { C, FH, FB, NEWS_ITEMS } from "../data";

type DTab = "overview"|"news"|"reviews"|"staff"|"settings";

const MONTHS = ["Янв","Фев","Мар","Апр","Май","Июн","Июл","Авг","Сен","Окт","Ноя","Дек"];
const CHART_DATA = MONTHS.map((m,i)=>({month:m, views: 120+Math.floor(Math.sin(i)*60+80), enquiries: 8+Math.floor(Math.cos(i)*5+8)}));

export function DashboardScreen() {
  const [dtab,  setDtab]  = useState<DTab>("overview");
  const [articles, setArticles] = useState(NEWS_ITEMS);
  const [showForm, setShowForm] = useState(false);
  const [editId, setEditId] = useState<string|null>(null);
  const [form, setForm] = useState({title:"",category:"Новости",content:"",coverUrl:"",videoUrl:"",tags:"",status:"draft" as "draft"|"published"});
  const [settingsTab, setSettingsTab] = useState<"info"|"contacts"|"hours"|"notify"|"security">("info");

  function resetForm() { setForm({title:"",category:"Новости",content:"",coverUrl:"",videoUrl:"",tags:"",status:"draft"}); setEditId(null); }

  function submitForm() {
    if(!form.title.trim()) return;
    if(editId!=null) {
      setArticles(prev=>prev.map(a=>a.id===editId?{...a,...form,tags:form.tags.split(",").map(t=>t.trim())}:a));
    } else {
      setArticles(prev=>[{id:String(Date.now()),date:new Date().toLocaleDateString("ru-RU"),views:0,...form,tags:form.tags.split(",").map(t=>t.trim())},...prev]);
    }
    setShowForm(false); resetForm();
  }

  function deleteArticle(id:string) { setArticles(prev=>prev.filter(a=>a.id!==id)); }
  function editArticle(a:any) {
    setForm({title:a.title,category:a.category,content:a.content??"",coverUrl:a.coverUrl??"",videoUrl:a.videoUrl??"",tags:(a.tags??[]).join(", "),status:a.status??"draft"});
    setEditId(a.id); setShowForm(true);
  }

  const TABS: {k:DTab;l:string;icon:any}[] = [
    {k:"overview",l:"Обзор",icon:TrendingUp},
    {k:"news",l:"Новости",icon:Newspaper},
    {k:"reviews",l:"Отзывы",icon:Star},
    {k:"staff",l:"Персонал",icon:Users},
    {k:"settings",l:"Настройки",icon:Settings},
  ];

  function Field({label,children}:{label:string;children:React.ReactNode}) {
    return (
      <div style={{marginBottom:16}}>
        <label style={{display:"block",fontSize:12.5,fontWeight:700,color:C.dim,textTransform:"uppercase",letterSpacing:".06em",fontFamily:FH,marginBottom:6}}>{label}</label>
        {children}
      </div>
    );
  }

  const inputStyle = {width:"100%",padding:"10px 13px",borderRadius:10,border:`1px solid ${C.border}`,background:C.s2,color:C.text,fontFamily:FB,fontSize:14,outline:"none",boxSizing:"border-box" as const};

  return (
    <div style={{display:"flex",height:"calc(100vh - 64px)",fontFamily:FB}}>
      {/* sidebar */}
      <aside style={{width:220,borderRight:`1px solid ${C.border}`,padding:"20px 0",flexShrink:0,background:C.s1}}>
        <div style={{padding:"0 16px 20px",borderBottom:`1px solid ${C.border}`,marginBottom:12}}>
          <div style={{width:48,height:48,borderRadius:14,background:C.teal,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:900,fontSize:22,color:C.bg,marginBottom:8}}>Л</div>
          <p style={{fontFamily:FH,fontWeight:800,fontSize:14,color:C.text}}>Лицей №1</p>
          <p style={{fontSize:12,color:C.ok}}>● Активен</p>
        </div>
        {TABS.map(({k,l,icon:Icon})=>(
          <button key={k} onClick={()=>setDtab(k)}
            style={{display:"flex",alignItems:"center",gap:10,width:"100%",padding:"10px 16px",fontSize:13.5,fontWeight:600,fontFamily:FH,color:dtab===k?C.teal:C.muted,background:dtab===k?`${C.teal}15`:"transparent",borderLeft:`3px solid ${dtab===k?C.teal:"transparent"}`,transition:"all .14s"}}>
            <Icon size={15}/> {l}
          </button>
        ))}
      </aside>

      {/* main */}
      <main style={{flex:1,overflowY:"auto",padding:"28px"}}>

        {/* ── OVERVIEW ── */}
        {dtab==="overview" && (
          <div>
            <h1 style={{fontFamily:FH,fontWeight:900,fontSize:26,color:C.text,marginBottom:24}}>Обзор учреждения</h1>
            <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:14,marginBottom:28}}>
              {[
                {l:"Просмотры профиля",v:"1 248",delta:"+12%",icon:Eye,color:C.teal},
                {l:"Новые заявки",v:"34",delta:"+7",icon:MessageSquare,color:C.gold},
                {l:"Рейтинг",v:"4.8 ★",delta:"+0.1",icon:Star,color:C.ok},
                {l:"Подписчики",v:"289",delta:"+18",icon:Users,color:C.red},
              ].map(({l,v,delta,icon:Icon,color})=>(
                <div key={l} style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,padding:"20px 18px"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:12}}>
                    <span style={{fontSize:13,color:C.sub,fontFamily:FH}}>{l}</span>
                    <span style={{width:34,height:34,borderRadius:9,background:`${color}18`,display:"flex",alignItems:"center",justifyContent:"center"}}><Icon size={16} style={{color}}/></span>
                  </div>
                  <p style={{fontFamily:FH,fontWeight:900,fontSize:26,color:C.text,marginBottom:4}}>{v}</p>
                  <p style={{fontSize:12.5,color:C.ok}}>{delta} за месяц</p>
                </div>
              ))}
            </div>
            <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:"22px 24px"}}>
              <h3 style={{fontFamily:FH,fontWeight:800,fontSize:17,color:C.text,marginBottom:20}}>Активность за год</h3>
              <ResponsiveContainer width="100%" height={240}>
                <BarChart data={CHART_DATA}>
                  <CartesianGrid strokeDasharray="3 3" stroke={C.s3}/>
                  <XAxis dataKey="month" tick={{fill:C.muted,fontSize:12}}/>
                  <YAxis tick={{fill:C.muted,fontSize:12}}/>
                  <Tooltip contentStyle={{background:C.s2,border:`1px solid ${C.border}`,borderRadius:10,color:C.text}}/>
                  <Bar dataKey="views"     name="Просмотры" fill={C.teal}     radius={[4,4,0,0]}/>
                  <Bar dataKey="enquiries" name="Заявки"    fill={C.gold}     radius={[4,4,0,0]}/>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* ── NEWS ── */}
        {dtab==="news" && (
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24}}>
              <h1 style={{fontFamily:FH,fontWeight:900,fontSize:26,color:C.text}}>Управление новостями</h1>
              <button onClick={()=>{resetForm();setShowForm(true)}} style={{display:"flex",alignItems:"center",gap:7,padding:"10px 18px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:700,fontSize:13.5}}>
                <Plus size={15}/> Добавить
              </button>
            </div>

            {/* article list */}
            <div style={{display:"flex",flexDirection:"column",gap:12}}>
              {articles.map(a=>(
                <div key={a.id} style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,padding:"16px 18px",display:"grid",gridTemplateColumns:"80px 1fr auto",gap:14,alignItems:"center"}}>
                  <div style={{width:80,height:56,borderRadius:10,overflow:"hidden",background:C.s3,flexShrink:0}}>
                    {a.coverUrl ? <img src={a.coverUrl} alt={a.title} style={{width:"100%",height:"100%",objectFit:"cover"}}/> : <div style={{width:"100%",height:"100%",display:"flex",alignItems:"center",justifyContent:"center"}}><Image size={20} style={{color:C.dim}}/></div>}
                  </div>
                  <div>
                    <div style={{display:"flex",gap:6,marginBottom:4}}>
                      <span style={{fontSize:11.5,fontWeight:700,color:C.teal,fontFamily:FH,textTransform:"uppercase"}}>{a.category}</span>
                      {a.videoUrl && <span style={{fontSize:11.5,fontWeight:700,color:C.gold,fontFamily:FH,display:"flex",alignItems:"center",gap:3}}><Video size={10}/>Видео</span>}
                      <span style={{fontSize:11.5,padding:"2px 8px",borderRadius:6,background:a.status==="published"?`${C.ok}22`:C.s3,color:a.status==="published"?C.ok:C.muted,fontFamily:FH,fontWeight:600,marginLeft:"auto"}}>
                        {a.status==="published"?"Опубликовано":"Черновик"}
                      </span>
                    </div>
                    <p style={{fontFamily:FH,fontWeight:700,fontSize:14.5,color:C.text,marginBottom:4}}>{a.title}</p>
                    <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
                      {(a.tags??[]).map(t=><span key={t} style={{fontSize:11.5,color:C.muted,background:C.s2,padding:"2px 8px",borderRadius:6}}>#{t}</span>)}
                    </div>
                  </div>
                  <div style={{display:"flex",gap:8}}>
                    <button onClick={()=>editArticle(a)} style={{width:32,height:32,borderRadius:8,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center"}}><Edit2 size={13} style={{color:C.teal}}/></button>
                    <button onClick={()=>deleteArticle(a.id)} style={{width:32,height:32,borderRadius:8,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center"}}><Trash2 size={13} style={{color:C.red}}/></button>
                  </div>
                </div>
              ))}
              {articles.length===0 && <div style={{padding:48,textAlign:"center",color:C.muted,borderRadius:16,border:`1px dashed ${C.border}`}}>Нет новостей. Нажмите «Добавить»</div>}
            </div>

            {/* ── ADD/EDIT FORM MODAL ── */}
            {showForm && (
              <div style={{position:"fixed",inset:0,background:"rgba(0,0,0,.7)",zIndex:999,display:"flex",alignItems:"center",justifyContent:"center",padding:20}}>
                <div style={{width:"100%",maxWidth:620,maxHeight:"90vh",overflowY:"auto",borderRadius:22,background:C.s1,border:`1px solid ${C.border}`,padding:"28px"}}>
                  <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:22}}>
                    <h2 style={{fontFamily:FH,fontWeight:900,fontSize:20,color:C.text}}>{editId?"Редактировать":"Добавить публикацию"}</h2>
                    <button onClick={()=>{setShowForm(false);resetForm()}}><X size={18} style={{color:C.muted}}/></button>
                  </div>

                  <Field label="Заголовок">
                    <input value={form.title} onChange={e=>setForm({...form,title:e.target.value})} style={inputStyle} placeholder="Заголовок статьи"/>
                  </Field>
                  <Field label="Категория">
                    <select value={form.category} onChange={e=>setForm({...form,category:e.target.value})} style={{...inputStyle,cursor:"pointer"}}>
                      {["Новости","Объявления","События","Достижения","Фото","Видео","Материалы"].map(c=><option key={c}>{c}</option>)}
                    </select>
                  </Field>
                  <Field label="Текст статьи">
                    <textarea value={form.content} onChange={e=>setForm({...form,content:e.target.value})} style={{...inputStyle,resize:"vertical",minHeight:120}} placeholder="Текст статьи..."/>
                  </Field>
                  <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                    <Field label="Обложка (URL фото)">
                      <input value={form.coverUrl} onChange={e=>setForm({...form,coverUrl:e.target.value})} style={inputStyle} placeholder="https://..."/>
                    </Field>
                    <Field label="Видео (URL)">
                      <input value={form.videoUrl} onChange={e=>setForm({...form,videoUrl:e.target.value})} style={inputStyle} placeholder="YouTube URL..."/>
                    </Field>
                  </div>
                  <Field label="Теги (через запятую)">
                    <input value={form.tags} onChange={e=>setForm({...form,tags:e.target.value})} style={inputStyle} placeholder="олимпиада, победители, наука"/>
                  </Field>
                  <Field label="Статус">
                    <div style={{display:"flex",gap:10}}>
                      {(["draft","published"] as const).map(s=>(
                        <button key={s} onClick={()=>setForm({...form,status:s})}
                          style={{flex:1,padding:"9px",borderRadius:10,border:`2px solid ${form.status===s?C.teal:C.border}`,background:form.status===s?`${C.teal}18`:"transparent",color:form.status===s?C.teal:C.muted,fontFamily:FH,fontWeight:700,fontSize:13.5,transition:"all .14s"}}>
                          {s==="draft"?"Черновик":"Опубликовать"}
                        </button>
                      ))}
                    </div>
                  </Field>
                  <div style={{display:"flex",gap:10,marginTop:6}}>
                    <button onClick={()=>{setShowForm(false);resetForm()}} style={{flex:1,padding:"11px",borderRadius:11,border:`1px solid ${C.border}`,color:C.muted,fontFamily:FH,fontWeight:700,fontSize:14}}>Отмена</button>
                    <button onClick={submitForm} style={{flex:2,padding:"11px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14,display:"flex",alignItems:"center",justifyContent:"center",gap:7}}>
                      <Check size={15}/> {editId?"Сохранить":"Опубликовать"}
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ── REVIEWS ── */}
        {dtab==="reviews" && (
          <div>
            <h1 style={{fontFamily:FH,fontWeight:900,fontSize:26,color:C.text,marginBottom:24}}>Отзывы</h1>
            {[{author:"Мадина К.",score:5,date:"10 авг 2025",text:"Прекрасная школа! Учителя очень внимательны к детям, хорошая организация учёбы."},{author:"Олег Т.",score:4,date:"3 авг 2025",text:"В целом хорошее учреждение, но хотелось бы больше внеурочных мероприятий."},{author:"Фируза Н.",score:5,date:"28 июл 2025",text:"Наш ребёнок ходит уже второй год. Очень довольны!"}].map((r,i)=>(
              <div key={i} style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,padding:"18px 20px",marginBottom:12}}>
                <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                  <div style={{display:"flex",gap:10}}>
                    <div style={{width:38,height:38,borderRadius:"50%",background:C.teal,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:800,color:C.bg,fontSize:15}}>{r.author[0]}</div>
                    <div>
                      <p style={{fontFamily:FH,fontWeight:700,fontSize:14,color:C.text}}>{r.author}</p>
                      <p style={{fontSize:12.5,color:C.sub}}>{r.date}</p>
                    </div>
                  </div>
                  <span style={{display:"flex",gap:2}}>{[1,2,3,4,5].map(i=><svg key={i} width={13} height={13} viewBox="0 0 24 24" fill={i<=r.score?C.gold:C.dim}><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>)}</span>
                </div>
                <p style={{fontSize:14,color:C.sub,lineHeight:1.7,marginBottom:12}}>{r.text}</p>
                <div style={{display:"flex",gap:8}}>
                  <button style={{fontSize:12.5,fontWeight:600,padding:"6px 12px",borderRadius:8,border:`1px solid ${C.teal}40`,color:C.teal,fontFamily:FH}}>Ответить</button>
                  <button style={{fontSize:12.5,fontWeight:600,padding:"6px 12px",borderRadius:8,border:`1px solid ${C.border}`,color:C.muted,fontFamily:FH}}>Пожаловаться</button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── STAFF MANAGEMENT ── */}
        {dtab==="staff" && (
          <div>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:24}}>
              <h1 style={{fontFamily:FH,fontWeight:900,fontSize:26,color:C.text}}>Управление персоналом</h1>
              <button style={{display:"flex",alignItems:"center",gap:7,padding:"10px 18px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:700,fontSize:13.5}}><Plus size={15}/> Добавить</button>
            </div>
            {["Директор","Учитель математики","Учитель английского","Психолог","Воспитатель"].map((role,i)=>(
              <div key={i} style={{borderRadius:14,border:`1px solid ${C.border}`,background:C.s1,padding:"14px 18px",marginBottom:10,display:"flex",alignItems:"center",justifyContent:"space-between"}}>
                <div style={{display:"flex",gap:12,alignItems:"center"}}>
                  <div style={{width:40,height:40,borderRadius:10,background:[C.teal,C.gold,C.red,C.ok,"#A78BFA"][i%5],display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:900,fontSize:16,color:"#fff"}}>
                    {["А","М","Н","Д","Л"][i]}
                  </div>
                  <div>
                    <p style={{fontFamily:FH,fontWeight:700,fontSize:14.5,color:C.text}}>{"Абдулло Шарипов,Мадина Рашидова,Нилуфар Исмоилова,Давронбек Кодиров,Лола Назарова".split(",")[i]}</p>
                    <p style={{fontSize:12.5,color:C.sub}}>{role}</p>
                  </div>
                </div>
                <div style={{display:"flex",gap:8}}>
                  <button style={{width:32,height:32,borderRadius:8,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center"}}><Edit2 size={13} style={{color:C.teal}}/></button>
                  <button style={{width:32,height:32,borderRadius:8,border:`1px solid ${C.border}`,display:"flex",alignItems:"center",justifyContent:"center"}}><Trash2 size={13} style={{color:C.red}}/></button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* ── SETTINGS ── */}
        {dtab==="settings" && (
          <div>
            <h1 style={{fontFamily:FH,fontWeight:900,fontSize:26,color:C.text,marginBottom:24}}>Настройки кабинета</h1>
            <div style={{display:"grid",gridTemplateColumns:"200px 1fr",gap:20,alignItems:"start"}}>
              <div style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,overflow:"hidden"}}>
                {(["info","contacts","hours","notify","security"] as const).map((k,i)=>{
                  const labels = ["Информация","Контакты","Режим работы","Уведомления","Безопасность"];
                  const icons = [Globe,MessageSquare,Bell,Bell,Lock];
                  const Icon = icons[i];
                  return (
                    <button key={k} onClick={()=>setSettingsTab(k)}
                      style={{display:"flex",alignItems:"center",gap:9,width:"100%",padding:"11px 14px",fontSize:13.5,fontWeight:600,fontFamily:FH,color:settingsTab===k?C.teal:C.muted,background:settingsTab===k?`${C.teal}15`:"transparent",borderLeft:`3px solid ${settingsTab===k?C.teal:"transparent"}`,transition:"all .14s"}}>
                      <Icon size={14}/>{labels[i]}
                    </button>
                  );
                })}
              </div>

              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:26}}>
                {settingsTab==="info" && (
                  <>
                    <h2 style={{fontFamily:FH,fontWeight:800,fontSize:19,color:C.text,marginBottom:18}}>Информация об учреждении</h2>
                    <Field label="Название">{<input defaultValue="Лицей №1 имени Рудаки" style={inputStyle}/>}</Field>
                    <Field label="Описание">{<textarea defaultValue="Государственное образовательное учреждение..." style={{...inputStyle,resize:"vertical",minHeight:100}}/>}</Field>
                    <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                      <Field label="Тип учреждения"><select style={{...inputStyle,cursor:"pointer"}}><option>Школа</option><option>Детсад</option><option>Учебный центр</option><option>Вуз</option></select></Field>
                      <Field label="Район"><select style={{...inputStyle,cursor:"pointer"}}><option>Сино</option><option>Фирдавсӣ</option><option>И. Сомонӣ</option><option>Шоҳмансур</option></select></Field>
                    </div>
                    <Field label="Директор">{<input defaultValue="Шарипов А.М." style={inputStyle}/>}</Field>
                    <button style={{marginTop:8,padding:"11px 24px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14}}>Сохранить изменения</button>
                  </>
                )}
                {settingsTab==="contacts" && (
                  <>
                    <h2 style={{fontFamily:FH,fontWeight:800,fontSize:19,color:C.text,marginBottom:18}}>Контактная информация</h2>
                    <Field label="Телефон">{<input defaultValue="+992 37 123-45-67" style={inputStyle}/>}</Field>
                    <Field label="Email">{<input defaultValue="lisey1@edu.tj" style={inputStyle}/>}</Field>
                    <Field label="Веб-сайт">{<input defaultValue="https://lisey1.tj" style={inputStyle}/>}</Field>
                    <Field label="Адрес">{<input defaultValue="ул. Рудаки 15, Душанбе" style={inputStyle}/>}</Field>
                    <button style={{marginTop:8,padding:"11px 24px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14}}>Сохранить</button>
                  </>
                )}
                {settingsTab==="hours" && (
                  <>
                    <h2 style={{fontFamily:FH,fontWeight:800,fontSize:19,color:C.text,marginBottom:18}}>Режим работы</h2>
                    {["Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"].map((d,i)=>(
                      <div key={d} style={{display:"grid",gridTemplateColumns:"140px 1fr 1fr 40px",gap:10,alignItems:"center",marginBottom:10}}>
                        <span style={{fontSize:13.5,color:C.text,fontFamily:FH}}>{d}</span>
                        <input defaultValue={i<5?"07:30":"08:00"} style={{...inputStyle,textAlign:"center"}}/>
                        <input defaultValue={i<5?"18:00":i===5?"14:00":"Выходной"} style={{...inputStyle,textAlign:"center"}}/>
                        <input type="checkbox" defaultChecked={i<6} style={{accentColor:C.teal,width:18,height:18}}/>
                      </div>
                    ))}
                    <button style={{marginTop:8,padding:"11px 24px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14}}>Сохранить</button>
                  </>
                )}
                {settingsTab==="notify" && (
                  <>
                    <h2 style={{fontFamily:FH,fontWeight:800,fontSize:19,color:C.text,marginBottom:18}}>Уведомления</h2>
                    {[{l:"Новый отзыв",d:"Уведомлять при новом отзыве"},{l:"Новая заявка",d:"Уведомлять при поступлении заявки"},{l:"Новое сообщение",d:"Push-уведомление в чате"},{l:"Еженедельный отчёт",d:"Статистика по email"}].map((n,i)=>(
                      <div key={i} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"14px 0",borderBottom:`1px solid ${C.border}`}}>
                        <div><p style={{fontFamily:FH,fontWeight:600,fontSize:14,color:C.text}}>{n.l}</p><p style={{fontSize:12.5,color:C.sub}}>{n.d}</p></div>
                        <div style={{position:"relative",width:44,height:24,cursor:"pointer"}}>
                          <div style={{position:"absolute",inset:0,borderRadius:999,background:i<3?C.teal:C.s3}}/>
                          <div style={{position:"absolute",top:3,left:i<3?23:3,width:18,height:18,borderRadius:"50%",background:"#fff",transition:"left .18s"}}/>
                        </div>
                      </div>
                    ))}
                  </>
                )}
                {settingsTab==="security" && (
                  <>
                    <h2 style={{fontFamily:FH,fontWeight:800,fontSize:19,color:C.text,marginBottom:18}}>Безопасность</h2>
                    <Field label="Текущий пароль">{<input type="password" placeholder="••••••••" style={inputStyle}/>}</Field>
                    <Field label="Новый пароль">{<input type="password" placeholder="••••••••" style={inputStyle}/>}</Field>
                    <Field label="Подтвердите пароль">{<input type="password" placeholder="••••••••" style={inputStyle}/>}</Field>
                    <button style={{marginTop:8,padding:"11px 24px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14}}>Обновить пароль</button>
                    <div style={{marginTop:24,padding:18,borderRadius:14,border:`1px solid ${C.red}33`,background:`${C.red}10`}}>
                      <p style={{fontFamily:FH,fontWeight:700,fontSize:14,color:C.red,marginBottom:6}}>Двухфакторная аутентификация</p>
                      <p style={{fontSize:13,color:C.sub,marginBottom:12}}>Включите 2FA для дополнительной защиты аккаунта</p>
                      <button style={{padding:"8px 18px",borderRadius:9,border:`1px solid ${C.red}44`,color:C.red,fontFamily:FH,fontWeight:700,fontSize:13}}>Включить 2FA</button>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
