import { useState } from "react";
import { Heart, Star, MessageSquare, Settings, LogOut, Edit2, Plus, ChevronRight, Check } from "lucide-react";
import { C, FH, FB, INSTITUTIONS, PHOTOS } from "../data";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";

const USER = {
  name: "Мадина Рашидова",
  email: "madina.rashidova@gmail.com",
  phone: "+992 98 765-43-21",
  city: "Душанбе",
  photo: PHOTOS.pw1,
  children: [
    { name: "Алишер", age: 8, school: "Лицей №1" },
    { name: "Зулайхо", age: 5, school: "Детсад «Гулнора»" },
  ],
};

const USER_REVIEWS = [
  { instName:"Лицей №1", score:5, text:"Отличная школа, рекомендую всем!", date:"10 авг 2025" },
  { instName:"Детсад «Гулнора»", score:4, text:"Хорошие воспитатели, но кормят не очень.", date:"3 авг 2025" },
];

type UTab = "saved"|"reviews"|"children"|"settings";

function Stars({ s }:{s:number}) {
  return <span style={{display:"flex",gap:2}}>{[1,2,3,4,5].map(i=>(<svg key={i} width={12} height={12} viewBox="0 0 24 24" fill={i<=Math.round(s)?C.gold:C.dim}><path d="M12 2l3 7h7l-5.5 4 2 7L12 16l-6.5 4 2-7L2 9h7z"/></svg>))}</span>;
}

export function UserProfilePage({ set, setInstId }: { set:(s:Screen)=>void; setInstId:(id:number)=>void }) {
  const [tab, setTab] = useState<UTab>("saved");
  const [savedIds] = useState([1,3]);

  const savedInst = INSTITUTIONS.filter(i=>savedIds.includes(i.id));

  const TABS: {k:UTab;l:string;icon:any}[] = [
    {k:"saved",    l:"Избранное",  icon:Heart},
    {k:"reviews",  l:"Мои отзывы", icon:Star},
    {k:"children", l:"Дети",       icon:MessageSquare},
    {k:"settings", l:"Настройки",  icon:Settings},
  ];

  const inputStyle = {width:"100%",padding:"10px 13px",borderRadius:10,border:`1px solid ${C.border}`,background:C.s2,color:C.text,fontFamily:FB,fontSize:14,outline:"none",boxSizing:"border-box" as const};

  return (
    <div style={{maxWidth:1200,margin:"0 auto",padding:"32px 28px 80px",fontFamily:FB}}>
      <div style={{display:"grid",gridTemplateColumns:"280px 1fr",gap:24,alignItems:"start"}}>

        {/* ── LEFT PROFILE CARD ── */}
        <div style={{borderRadius:20,border:`1px solid ${C.border}`,background:C.s1,overflow:"hidden"}}>
          <div style={{height:120,background:`linear-gradient(135deg,${C.teal}33,${C.gold}22)`,position:"relative"}}>
            <div style={{position:"absolute",bottom:-36,left:"50%",transform:"translateX(-50%)",width:72,height:72,borderRadius:20,overflow:"hidden",border:`3px solid ${C.bg}`}}>
              <img src={USER.photo} alt={USER.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
            </div>
          </div>
          <div style={{padding:"44px 20px 20px",textAlign:"center"}}>
            <p style={{fontFamily:FH,fontWeight:900,fontSize:18,color:C.text,marginBottom:4}}>{USER.name}</p>
            <p style={{fontSize:13.5,color:C.sub,marginBottom:4}}>{USER.email}</p>
            <p style={{fontSize:13.5,color:C.sub,marginBottom:16}}>{USER.phone}</p>
            <div style={{display:"flex",gap:6,justifyContent:"center",marginBottom:18}}>
              <span style={{fontSize:12,fontWeight:700,padding:"4px 10px",borderRadius:7,background:`${C.teal}18`,color:C.teal,fontFamily:FH}}>Родитель</span>
              <span style={{fontSize:12,fontWeight:700,padding:"4px 10px",borderRadius:7,background:`${C.ok}18`,color:C.ok,fontFamily:FH}}>✓ Подтверждён</span>
            </div>
            <button style={{width:"100%",padding:"9px",borderRadius:10,border:`1px solid ${C.border}`,color:C.muted,fontFamily:FH,fontWeight:700,fontSize:13,display:"flex",alignItems:"center",justifyContent:"center",gap:7,marginBottom:8}}>
              <Edit2 size={13}/> Редактировать профиль
            </button>
            <button style={{width:"100%",padding:"9px",borderRadius:10,border:`1px solid ${C.red}33`,color:C.red,fontFamily:FH,fontWeight:700,fontSize:13,display:"flex",alignItems:"center",justifyContent:"center",gap:7}}>
              <LogOut size={13}/> Выйти
            </button>
          </div>

          {/* stats */}
          <div style={{borderTop:`1px solid ${C.border}`,display:"grid",gridTemplateColumns:"1fr 1fr 1fr"}}>
            {[{n:savedIds.length,l:"Избранных"},{n:USER_REVIEWS.length,l:"Отзывов"},{n:USER.children.length,l:"Детей"}].map(({n,l})=>(
              <div key={l} style={{padding:"14px 10px",textAlign:"center",borderRight:`1px solid ${C.border}`}}>
                <p style={{fontFamily:FH,fontWeight:900,fontSize:20,color:C.text}}>{n}</p>
                <p style={{fontSize:11.5,color:C.sub}}>{l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* ── RIGHT MAIN ── */}
        <div>
          {/* tabs */}
          <div style={{display:"flex",gap:4,marginBottom:24,borderBottom:`1px solid ${C.border}`,paddingBottom:0}}>
            {TABS.map(({k,l,icon:Icon})=>(
              <button key={k} onClick={()=>setTab(k)}
                style={{display:"flex",alignItems:"center",gap:7,padding:"11px 16px",fontFamily:FH,fontWeight:700,fontSize:13.5,color:tab===k?C.teal:C.muted,borderBottom:`2px solid ${tab===k?C.teal:"transparent"}`,whiteSpace:"nowrap",transition:"all .14s"}}>
                <Icon size={14}/> {l}
              </button>
            ))}
          </div>

          {/* SAVED */}
          {tab==="saved" && (
            <div>
              <h2 style={{fontFamily:FH,fontWeight:800,fontSize:20,color:C.text,marginBottom:16}}>Избранные учреждения</h2>
              {savedInst.length===0 ? (
                <div style={{padding:48,textAlign:"center",color:C.muted,borderRadius:16,border:`1px dashed ${C.border}`}}>
                  <Heart size={28} style={{margin:"0 auto 12px",color:C.dim}}/>
                  <p style={{fontFamily:FH,fontWeight:700,fontSize:16,color:C.text,marginBottom:6}}>Пока ничего нет</p>
                  <p style={{fontSize:13.5}}>Сохраняйте учреждения, нажав на ♡</p>
                  <button onClick={()=>set("search")} style={{marginTop:14,padding:"9px 20px",borderRadius:10,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:700,fontSize:13.5}}>Перейти к поиску</button>
                </div>
              ) : (
                <div style={{display:"flex",flexDirection:"column",gap:12}}>
                  {savedInst.map(inst=>(
                    <div key={inst.id} style={{display:"grid",gridTemplateColumns:"90px 1fr auto",gap:14,alignItems:"center",borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,padding:"12px 16px"}}>
                      <div style={{width:90,height:64,borderRadius:10,overflow:"hidden"}}>
                        <img src={inst.coverPhoto} alt={inst.name} style={{width:"100%",height:"100%",objectFit:"cover"}}/>
                      </div>
                      <div>
                        <p style={{fontFamily:FH,fontWeight:700,fontSize:15,color:C.text,marginBottom:4}}>{inst.name}</p>
                        <p style={{fontSize:13,color:C.sub,marginBottom:4}}>{inst.area} · {inst.type}</p>
                        <div style={{display:"flex",alignItems:"center",gap:6}}>
                          <Stars s={inst.score}/>
                          <span style={{fontSize:12.5,color:C.muted}}>({inst.rev})</span>
                          <span style={{fontSize:13.5,fontFamily:FH,fontWeight:700,color:C.text,marginLeft:8}}>{inst.price} сом/мес</span>
                        </div>
                      </div>
                      <button onClick={()=>{setInstId(inst.id);set("profile")}} style={{display:"flex",alignItems:"center",gap:5,padding:"8px 14px",borderRadius:9,border:`1px solid ${C.teal}40`,color:C.teal,fontFamily:FH,fontWeight:700,fontSize:13}}>
                        Открыть <ChevronRight size={14}/>
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* REVIEWS */}
          {tab==="reviews" && (
            <div>
              <h2 style={{fontFamily:FH,fontWeight:800,fontSize:20,color:C.text,marginBottom:16}}>Мои отзывы</h2>
              <div style={{display:"flex",flexDirection:"column",gap:12}}>
                {USER_REVIEWS.map((r,i)=>(
                  <div key={i} style={{borderRadius:16,border:`1px solid ${C.border}`,background:C.s1,padding:"18px 20px"}}>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10}}>
                      <p style={{fontFamily:FH,fontWeight:700,fontSize:15,color:C.text}}>{r.instName}</p>
                      <Stars s={r.score}/>
                    </div>
                    <p style={{fontSize:14,color:C.sub,lineHeight:1.7,marginBottom:10}}>{r.text}</p>
                    <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                      <span style={{fontSize:12.5,color:C.muted}}>{r.date}</span>
                      <button style={{display:"flex",alignItems:"center",gap:5,fontSize:13,fontWeight:600,color:C.teal,fontFamily:FH}}><Edit2 size={12}/> Редактировать</button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CHILDREN */}
          {tab==="children" && (
            <div>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:16}}>
                <h2 style={{fontFamily:FH,fontWeight:800,fontSize:20,color:C.text}}>Мои дети</h2>
                <button style={{display:"flex",alignItems:"center",gap:6,padding:"9px 16px",borderRadius:10,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:700,fontSize:13.5}}>
                  <Plus size={14}/> Добавить
                </button>
              </div>
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:14}}>
                {USER.children.map(ch=>(
                  <div key={ch.name} style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:"22px 20px"}}>
                    <div style={{width:56,height:56,borderRadius:16,background:`${C.teal}30`,display:"flex",alignItems:"center",justifyContent:"center",fontFamily:FH,fontWeight:900,fontSize:24,color:C.teal,marginBottom:14}}>{ch.name[0]}</div>
                    <p style={{fontFamily:FH,fontWeight:800,fontSize:17,color:C.text,marginBottom:4}}>{ch.name}</p>
                    <p style={{fontSize:13.5,color:C.sub,marginBottom:8}}>{ch.age} лет</p>
                    <div style={{display:"flex",alignItems:"center",gap:6,fontSize:13,color:C.sub}}>
                      <Check size={13} style={{color:C.ok}}/>{ch.school}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* SETTINGS */}
          {tab==="settings" && (
            <div>
              <h2 style={{fontFamily:FH,fontWeight:800,fontSize:20,color:C.text,marginBottom:18}}>Настройки профиля</h2>
              <div style={{borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,padding:26}}>
                <div style={{marginBottom:14}}>
                  <label style={{display:"block",fontSize:12.5,fontWeight:700,color:C.dim,textTransform:"uppercase",letterSpacing:".06em",fontFamily:FH,marginBottom:6}}>Имя</label>
                  <input defaultValue={USER.name} style={inputStyle}/>
                </div>
                <div style={{marginBottom:14}}>
                  <label style={{display:"block",fontSize:12.5,fontWeight:700,color:C.dim,textTransform:"uppercase",letterSpacing:".06em",fontFamily:FH,marginBottom:6}}>Email</label>
                  <input defaultValue={USER.email} style={inputStyle}/>
                </div>
                <div style={{marginBottom:14}}>
                  <label style={{display:"block",fontSize:12.5,fontWeight:700,color:C.dim,textTransform:"uppercase",letterSpacing:".06em",fontFamily:FH,marginBottom:6}}>Телефон</label>
                  <input defaultValue={USER.phone} style={inputStyle}/>
                </div>
                <div style={{marginBottom:20}}>
                  <label style={{display:"block",fontSize:12.5,fontWeight:700,color:C.dim,textTransform:"uppercase",letterSpacing:".06em",fontFamily:FH,marginBottom:6}}>Город</label>
                  <input defaultValue={USER.city} style={inputStyle}/>
                </div>
                <button style={{padding:"11px 24px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14}}>Сохранить изменения</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
