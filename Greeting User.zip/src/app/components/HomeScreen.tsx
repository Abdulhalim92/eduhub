import { useState } from "react";
import { Search, ArrowRight, Star, ChevronRight, TrendingUp, MapPin, Users, Award, Sparkles } from "lucide-react";
import { C, FH, FB, INSTITUTIONS, PHOTOS } from "../data";
import { InstitCard } from "./InstitCard";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";

const CATEGORIES = [
  { k:"cat_kg",    emoji:"🧒", label:"Детские сады",    count:124, color:"#4EC9F0", desc:"Ранее развитие" },
  { k:"cat_school",emoji:"🎓", label:"Школы",            count:87,  color:C.gold,    desc:"Общее образование" },
  { k:"cat_center",emoji:"📖", label:"Учебные центры",  count:56,  color:C.ok,      desc:"Курсы, репетиторы" },
  { k:"cat_uni",   emoji:"🏛", label:"Вузы и колледжи", count:32,  color:C.red,     desc:"Высшее образование" },
];

const STATS = [
  { n:"2 400+",  l:"Учреждений" },
  { n:"45 000+", l:"Отзывов" },
  { n:"120 000+",l:"Семей" },
  { n:"4.7",     l:"Ср. рейтинг" },
];

export function HomeScreen({ set, setInstId }: { set:(s:Screen)=>void; setInstId:(id:number)=>void }) {
  const [q, setQ] = useState("");

  const featured = INSTITUTIONS.slice(0, 3);
  const top = [...INSTITUTIONS].sort((a,b)=>b.score-a.score).slice(0,4);

  function handleSearch() { set("search"); }

  return (
    <div style={{fontFamily:FB}}>
      {/* ── HERO ── */}
      <section style={{position:"relative",overflow:"hidden",padding:"80px 28px 90px",textAlign:"center",background:`radial-gradient(ellipse 80% 70% at 50% -10%, ${C.teal}20, transparent)`}}>
        {/* decorative orbs */}
        <div style={{position:"absolute",top:-120,left:-80,width:500,height:500,borderRadius:"50%",background:`radial-gradient(circle,${C.teal}12,transparent 70%)`,pointerEvents:"none"}}/>
        <div style={{position:"absolute",bottom:-80,right:-60,width:400,height:400,borderRadius:"50%",background:`radial-gradient(circle,${C.gold}10,transparent 70%)`,pointerEvents:"none"}}/>

        <div style={{position:"relative",maxWidth:760,margin:"0 auto"}}>
          <div style={{display:"inline-flex",alignItems:"center",gap:7,padding:"6px 14px",borderRadius:999,border:`1px solid ${C.teal}44`,background:`${C.teal}12`,marginBottom:22}}>
            <Sparkles size={13} style={{color:C.teal}}/>
            <span style={{fontSize:12.5,fontWeight:700,color:C.teal,fontFamily:FH,letterSpacing:".04em"}}>Национальная образовательная платформа</span>
          </div>

          <h1 style={{fontFamily:FH,fontWeight:900,fontSize:"clamp(34px,5.5vw,64px)",lineHeight:1.08,color:C.text,marginBottom:18,letterSpacing:"-.02em"}}>
            Найдите лучшее<br/>
            <span style={{color:C.teal}}>учебное заведение</span><br/>
            для вашего ребёнка
          </h1>
          <p style={{fontSize:"clamp(14px,1.8vw,17px)",color:C.sub,marginBottom:38,lineHeight:1.65,maxWidth:540,margin:"0 auto 38px"}}>
            Сравнивайте школы, детские сады и учебные центры Таджикистана. Читайте честные отзывы родителей и делайте осознанный выбор.
          </p>

          {/* search bar */}
          <div style={{display:"flex",maxWidth:560,margin:"0 auto",borderRadius:14,overflow:"hidden",boxShadow:"0 8px 40px rgba(0,0,0,.5)",border:`1px solid ${C.teal}44`}}>
            <div style={{flex:1,display:"flex",alignItems:"center",gap:10,background:C.s1,padding:"14px 18px"}}>
              <Search size={17} style={{color:C.teal,flexShrink:0}}/>
              <input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==="Enter"&&handleSearch()} placeholder="Школа, детсад, район…"
                style={{flex:1,background:"transparent",border:"none",outline:"none",fontSize:15,color:C.text,fontFamily:FB}}/>
            </div>
            <button onClick={handleSearch} style={{padding:"0 26px",background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14,whiteSpace:"nowrap",flexShrink:0}}>
              Найти
            </button>
          </div>

          {/* quick chips */}
          <div style={{display:"flex",gap:8,justifyContent:"center",flexWrap:"wrap",marginTop:16}}>
            {["Лучшие школы","С развозкой","Халяль питание","Рядом с метро"].map(l=>(
              <button key={l} onClick={handleSearch} style={{fontSize:12.5,fontWeight:600,padding:"5px 13px",borderRadius:8,border:`1px solid ${C.border}`,color:C.sub,background:"transparent",fontFamily:FH,transition:"all .12s"}}>
                {l}
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* ── STATS ── */}
      <section style={{borderTop:`1px solid ${C.border}`,borderBottom:`1px solid ${C.border}`,padding:"28px 28px"}}>
        <div style={{maxWidth:1260,margin:"0 auto",display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:12}}>
          {STATS.map(s=>(
            <div key={s.l} style={{textAlign:"center"}}>
              <p style={{fontFamily:FH,fontWeight:900,fontSize:30,color:C.teal,marginBottom:4}}>{s.n}</p>
              <p style={{fontSize:13,color:C.sub}}>{s.l}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── CATEGORIES ── */}
      <section style={{maxWidth:1260,margin:"0 auto",padding:"56px 28px 0"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:28}}>
          <div>
            <h2 style={{fontFamily:FH,fontWeight:900,fontSize:"clamp(22px,3vw,32px)",color:C.text,letterSpacing:"-.02em"}}>Категории</h2>
            <p style={{fontSize:14,color:C.sub,marginTop:4}}>Выберите тип учреждения</p>
          </div>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:16}}>
          {CATEGORIES.map(cat=>(
            <button key={cat.k} onClick={()=>set("search")}
              style={{textAlign:"left",padding:"22px 20px",borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,cursor:"pointer",transition:"all .2s",position:"relative",overflow:"hidden"}}>
              <div style={{position:"absolute",top:-20,right:-20,width:100,height:100,borderRadius:"50%",background:`radial-gradient(circle,${cat.color}18,transparent 70%)`,pointerEvents:"none"}}/>
              <div style={{fontSize:34,marginBottom:12}}>{cat.emoji}</div>
              <p style={{fontFamily:FH,fontWeight:800,fontSize:17,color:C.text,marginBottom:4}}>{cat.label}</p>
              <p style={{fontSize:12.5,color:C.sub,marginBottom:12}}>{cat.desc}</p>
              <div style={{display:"flex",justifyContent:"space-between",alignItems:"center"}}>
                <span style={{fontSize:12,fontWeight:700,color:cat.color,fontFamily:FH}}>{cat.count} учр.</span>
                <ArrowRight size={14} style={{color:cat.color}}/>
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* ── TOP RATED ── */}
      <section style={{maxWidth:1260,margin:"0 auto",padding:"56px 28px 0"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-end",marginBottom:28}}>
          <div>
            <h2 style={{fontFamily:FH,fontWeight:900,fontSize:"clamp(22px,3vw,32px)",color:C.text,letterSpacing:"-.02em"}}>Лучшие учреждения</h2>
            <p style={{fontSize:14,color:C.sub,marginTop:4}}>По оценкам родителей Душанбе</p>
          </div>
          <button onClick={()=>set("search")} style={{display:"flex",alignItems:"center",gap:5,fontFamily:FH,fontWeight:700,fontSize:13.5,color:C.teal,padding:"8px 14px",borderRadius:9,border:`1px solid ${C.teal}40`,background:`${C.teal}10`}}>
            Все учреждения <ChevronRight size={14}/>
          </button>
        </div>
        <div style={{display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:18}}>
          {top.map(inst=>(
            <InstitCard key={inst.id} inst={inst} onClick={()=>{setInstId(inst.id);set("profile")}} onCompare={()=>set("compare")}/>
          ))}
        </div>
      </section>

      {/* ── HERO FEATURED BANNER ── */}
      <section style={{maxWidth:1260,margin:"56px auto 0",padding:"0 28px"}}>
        <div style={{borderRadius:22,overflow:"hidden",position:"relative",height:260,display:"flex",alignItems:"center"}}>
          <img src={PHOTOS.university} alt="university" style={{position:"absolute",inset:0,width:"100%",height:"100%",objectFit:"cover"}}/>
          <div style={{position:"absolute",inset:0,background:"linear-gradient(90deg,rgba(7,24,26,.95) 0%,rgba(7,24,26,.5) 60%,transparent 100%)"}}/>
          <div style={{position:"relative",padding:"40px 44px",maxWidth:520}}>
            <div style={{display:"inline-flex",alignItems:"center",gap:6,padding:"5px 12px",borderRadius:8,background:`${C.gold}22`,border:`1px solid ${C.gold}44`,marginBottom:14}}>
              <Award size={12} style={{color:C.gold}}/>
              <span style={{fontSize:11.5,fontWeight:700,color:C.gold,fontFamily:FH}}>Топ выбор 2025</span>
            </div>
            <h3 style={{fontFamily:FH,fontWeight:900,fontSize:28,color:C.text,marginBottom:10,lineHeight:1.2}}>
              Найдите учреждение,<br/>которому можно доверять
            </h3>
            <p style={{fontSize:14,color:C.sub,marginBottom:20,lineHeight:1.6}}>Более 45 000 отзывов от реальных родителей. Подробные профили учреждений с фото и документами.</p>
            <button onClick={()=>set("search")} style={{display:"inline-flex",alignItems:"center",gap:7,padding:"11px 22px",borderRadius:11,background:C.teal,color:C.bg,fontFamily:FH,fontWeight:800,fontSize:14}}>
              Начать поиск <ArrowRight size={15}/>
            </button>
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ── */}
      <section style={{maxWidth:1260,margin:"0 auto",padding:"56px 28px 80px"}}>
        <h2 style={{fontFamily:FH,fontWeight:900,fontSize:"clamp(22px,3vw,32px)",color:C.text,textAlign:"center",letterSpacing:"-.02em",marginBottom:8}}>Как это работает</h2>
        <p style={{fontSize:14,color:C.sub,textAlign:"center",marginBottom:40}}>Три шага до лучшего выбора</p>
        <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:20}}>
          {[
            {n:"01",icon:"🔍",t:"Ищите",d:"Используйте фильтры: район, тип, цена, наличие развозки и питания"},
            {n:"02",icon:"⚖️",t:"Сравнивайте",d:"Сравнивайте до 4 учреждений одновременно по ключевым параметрам"},
            {n:"03",icon:"⭐",t:"Читайте отзывы",d:"Честные мнения родителей помогут вам сделать осознанный выбор"},
          ].map(s=>(
            <div key={s.n} style={{padding:"28px 24px",borderRadius:18,border:`1px solid ${C.border}`,background:C.s1,textAlign:"center"}}>
              <div style={{fontSize:36,marginBottom:12}}>{s.icon}</div>
              <div style={{fontFamily:FH,fontWeight:900,fontSize:13,color:C.teal,marginBottom:6}}>{s.n}</div>
              <p style={{fontFamily:FH,fontWeight:800,fontSize:19,color:C.text,marginBottom:8}}>{s.t}</p>
              <p style={{fontSize:13.5,color:C.sub,lineHeight:1.65}}>{s.d}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
