import { MapPin } from "lucide-react";
import { C, FH, FB } from "../data";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";

export function NavBar({ screen, set }: { screen:Screen; set:(s:Screen)=>void }) {
  const links: {k:Screen; l:string}[] = [
    {k:"home",l:"Главная"},{k:"search",l:"Поиск"},
    {k:"chat",l:"Чат"},{k:"compare",l:"Сравнение"},{k:"dashboard",l:"Кабинет"},
  ];
  return (
    <header style={{position:"sticky",top:0,zIndex:40,background:"rgba(7,24,26,0.92)",backdropFilter:"blur(20px)",borderBottom:`1px solid ${C.border}`}}>
      <div style={{maxWidth:1260,margin:"0 auto",padding:"0 28px",display:"flex",alignItems:"center",gap:8,height:64}}>
        <button onClick={()=>set("home")} style={{display:"flex",alignItems:"center",gap:9,flexShrink:0,marginRight:8}}>
          <svg width="32" height="32" viewBox="0 0 40 40" fill="none">
            <path d="M20 3 L24 15 L37 20 L24 25 L20 37 L16 25 L3 20 L16 15 Z" fill={C.teal}/>
            <path d="M20 8 L22.5 16 L31 20 L22.5 24 L20 32 L17.5 24 L9 20 L17.5 16 Z" fill={C.gold}/>
            <circle cx="20" cy="20" r="3.4" fill={C.red}/>
          </svg>
          <span style={{fontFamily:FH,fontWeight:900,fontSize:19,color:C.text,letterSpacing:"-.01em"}}>
            Edu<span style={{color:C.gold}}>Hub</span>
          </span>
        </button>

        <nav style={{display:"flex",gap:2}}>
          {links.map(({k,l})=>(
            <button key={k} onClick={()=>set(k)} style={{padding:"7px 13px",borderRadius:10,fontSize:13.5,fontWeight:600,fontFamily:FH,color:screen===k?C.text:C.muted,background:screen===k?"rgba(255,255,255,0.06)":"transparent",transition:"all .14s"}}>
              {l}
            </button>
          ))}
        </nav>

        <div style={{marginLeft:"auto",display:"flex",gap:9,alignItems:"center"}}>
          <div style={{display:"flex",alignItems:"center",gap:5,padding:"7px 12px",borderRadius:9,border:`1px solid ${C.border}`,fontSize:13,fontWeight:500,color:C.sub,fontFamily:FB}}>
            <MapPin size={12}/> Душанбе
          </div>
          <div style={{display:"flex",borderRadius:9,overflow:"hidden",border:`1px solid ${C.border}`}}>
            <button style={{padding:"7px 11px",fontSize:12.5,fontWeight:700,color:C.muted,fontFamily:FH}}>ТҶ</button>
            <button style={{padding:"7px 11px",fontSize:12.5,fontWeight:700,background:C.teal,color:C.bg,fontFamily:FH}}>РУ</button>
          </div>
          <button onClick={()=>set("user-profile")} style={{padding:"8px 16px",borderRadius:9,fontFamily:FH,fontWeight:700,fontSize:13,background:C.gold,color:C.bg}}>
            Войти
          </button>
        </div>
      </div>
    </header>
  );
}
