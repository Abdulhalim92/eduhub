import { useState } from "react";
import { C } from "./data";
import { NavBar } from "./components/NavBar";
import { HomeScreen } from "./components/HomeScreen";
import { SearchScreen } from "./components/SearchScreen";
import { ProfileScreen } from "./components/ProfileScreen";
import { PersonPage } from "./components/PersonPage";
import { CompareScreen } from "./components/CompareScreen";
import { ChatScreen } from "./components/ChatScreen";
import { DashboardScreen } from "./components/DashboardScreen";
import { UserProfilePage } from "./components/UserProfilePage";

type Screen = "home"|"search"|"profile"|"person"|"compare"|"chat"|"dashboard"|"user-profile";

export default function App() {
  const [screen,   setScreen]   = useState<Screen>("home");
  const [instId,   setInstId]   = useState(1);
  const [personId, setPersonId] = useState<string>("p1");

  function set(s:Screen) { setScreen(s); window.scrollTo(0,0); }

  return (
    <div style={{minHeight:"100vh",background:C.bg,color:C.text}}>
      {screen !== "dashboard" && (
        <NavBar screen={screen} set={set}/>
      )}

      {screen==="home"         && <HomeScreen       set={set} setInstId={setInstId}/>}
      {screen==="search"       && <SearchScreen     set={set} setInstId={setInstId}/>}
      {screen==="profile"      && <ProfileScreen    set={set} instId={instId} setPersonId={setPersonId}/>}
      {screen==="person"       && <PersonPage       set={set} personId={personId}/>}
      {screen==="compare"      && <CompareScreen    set={set} setInstId={setInstId}/>}
      {screen==="chat"         && <ChatScreen       set={set}/>}
      {screen==="dashboard"    && <DashboardScreen  />}
      {screen==="user-profile" && <UserProfilePage  set={set} setInstId={setInstId}/>}
    </div>
  );
}
